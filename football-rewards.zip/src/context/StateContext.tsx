import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { User, Match, Prediction, PromoCode, PointsLog, Badge, SystemConfig, PushNotification, SystemLog } from '../types';
import { INITIAL_USERS, INITIAL_MATCHES, INITIAL_CODES, INITIAL_LOGS, BADGES, DEFAULT_CONFIG, INITIAL_SYSTEM_LOGS } from '../data';

const COUNTRY_FLAGS: { [key: string]: string } = {
  'Argentina': '🇦🇷',
  'Francia': '🇫🇷',
  'France': '🇫🇷',
  'España': '🇪🇸',
  'Spain': '🇪🇸',
  'Alemania': '🇩🇪',
  'Germany': '🇩🇪',
  'Brasil': '🇧🇷',
  'Brazil': '🇧🇷',
  'Colombia': '🇨🇴',
  'Inglaterra': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
  'England': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
  'Estados Unidos': '🇺🇸',
  'United States': '🇺🇸',
  'USA': '🇺🇸',
  'Portugal': '🇵🇹',
  'Uruguay': '🇺🇾',
  'México': '🇲🇽',
  'Mexico': '🇲🇽',
  'Japón': '🇯🇵',
  'Japan': '🇯🇵',
  'Bélgica': '🇧🇪',
  'Belgium': '🇧🇪',
  'Marruecos': '🇲🇦',
  'Morocco': '🇲🇦',
  'Croacia': '🇭🇷',
  'Croatia': '🇭🇷',
  'Canadá': '🇨🇦',
  'Canada': '🇨🇦',
  'Ecuador': '🇪🇨',
  'Qatar': '🇶🇦',
  'Senegal': '🇸🇳',
  'Holanda': '🇳🇱',
  'Netherlands': '🇳🇱',
  'Países Bajos': '🇳🇱',
  'Gales': '🏴󠁧󠁢󠁷󠁬󠁳󠁿',
  'Wales': '🏴󠁧󠁢󠁷󠁬󠁳󠁿',
  'Irán': '🇮🇷',
  'Iran': '🇮🇷',
  'Arabia Saudita': '🇸🇦',
  'Saudi Arabia': '🇸🇦',
  'Polonia': '🇵🇱',
  'Poland': '🇵🇱',
  'Dinamarca': '🇩🇰',
  'Denmark': '🇩🇰',
  'Túnez': '🇹🇳',
  'Tunisia': '🇹🇳',
  'Australia': '🇦🇺',
  'Costa Rica': '🇨🇷',
  'Suiza': '🇨🇭',
  'Switzerland': '🇨🇭',
  'Camerún': '🇨🇲',
  'Cameroon': '🇨🇲',
  'Serbia': '🇷🇸',
  'Ghana': '🇬🇭',
  'Corea del Sur': '🇰🇷',
  'South Korea': '🇰🇷',
  'Italia': '🇮🇹',
  'Italy': '🇮🇹',
  'Suecia': '🇸🇪',
  'Sweden': '🇸🇪',
  'Ucrania': '🇺🇦',
  'Ukraine': '🇺🇦',
  'Escocia': '🏴󠁧󠁢󠁳󠁣󠁴󠁿',
  'Scotland': '🏴󠁧󠁢󠁳󠁣󠁴󠁿',
  'Perú': '🇵🇪',
  'Peru': '🇵🇪',
  'Chile': '🇨🇱',
  'Venezuela': '🇻🇪',
  'Paraguay': '🇵🇾',
  'Bolivia': '🇧🇴',
  'Argelia': '🇩🇿',
  'Algeria': '🇩🇿',
  'Nigeria': '🇳🇬',
  'Egipto': '🇪🇬',
  'Egypt': '🇪🇬',
  'África del Sur': '🇿🇦',
  'South Africa': '🇿🇦',
  'Nueva Zelanda': '🇳🇿',
  'New Zealand': '🇳🇿',
  'Honduras': '🇭🇳',
  'Panamá': '🇵🇦',
  'Panama': '🇵🇦',
  'Jamaica': '🇯🇲',
  'Slovakia': '🇸🇰',
  'Austria': '🇦🇹',
  'Turkey': '🇹🇷',
  'Turquía': '🇹🇷',
  'Czechia': '🇨🇿',
  'República Checa': '🇨🇿',
  'Georgia': '🇬🇪',
  'Greece': '🇬🇷',
  'Rumania': '🇷🇴',
  'Hungary': '🇭🇺',
  'Slovenia': '🇸🇮',
  'Eslovaca': '🇸🇰',
};

interface StateContextType {
  activeRole: 'CLIENT' | 'ADMIN';
  setActiveRole: (role: 'CLIENT' | 'ADMIN') => void;
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  isAdmin: boolean;
  users: User[];
  matches: Match[];
  predictions: Prediction[];
  promoCodes: PromoCode[];
  pointsLogs: PointsLog[];
  systemLogs: SystemLog[];
  notifications: PushNotification[];
  systemConfig: SystemConfig;
  badges: Badge[];
  
  // Auth
  sendOtp: (name: string, phone: string) => { success: boolean; code: string };
  verifyOtp: (phone: string, name: string, code: string) => { success: boolean; user?: User; error?: string };
  logout: () => void;
  
  // Actions
  placePrediction: (matchId: string, predictedWinner: 'LOCAL' | 'DRAW' | 'AWAY', homeScore: number, awayScore: number) => { success: boolean; message: string };
  claimPromoCode: (codeHex: string) => { success: boolean; message: string; pointsAwarded?: number };
  syncRealMatchesFromESPN: () => Promise<{ success: boolean; message: string }>;
  
  // Admin Actions
  adminCreateCode: (code: string, purchaseValue: number, points: number, expirationDate: string, maxUses: number) => { success: boolean; message: string };
  adminToggleCodeStatus: (codeId: string) => void;
  adminDeleteCode: (codeId: string) => void;
  adminUpdateMatch: (matchId: string, homeScore: number, awayScore: number, status: 'PENDING' | 'LIVE' | 'FINISHED') => void;
  adminUpdateConfig: (config: SystemConfig) => void;
  adminToggleUserBlock: (userId: string) => void;
  adminDeleteUser: (userId: string) => void;
  adminTriggerNotification: (title: string, body: string, type: 'MATCH' | 'POINTS' | 'RANKING' | 'SYSTEM') => void;
  adminAddMatch: (match: Omit<Match, "id">) => void;
  adminDeleteMatch: (matchId: string) => void;
  adminUpdateUserPoints: (userId: string, points: number, pointsFromPredictions?: number, pointsFromPurchases?: number) => void;
  
  // Helpers
  getLeaderboardStats: () => {
    top10: User[];
    userRank: number;
    pointsToTop10: number;
    pointsToLeader: number;
    distanceToLeader: number;
  };
  getCalculatedBadges: (userId: string) => Badge[];
}

const StateContext = createContext<StateContextType | undefined>(undefined);

export const StateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeRole, setActiveRole] = useState<'CLIENT' | 'ADMIN'>('CLIENT');
  const lastSaveTimeRef = useRef<number>(0);
  
  // Main states synced with localStorage
  const [currentUser, setCurrentUserState] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([]);
  const [pointsLogs, setPointsLogs] = useState<PointsLog[]>([]);
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([]);
  const [notifications, setNotifications] = useState<PushNotification[]>([]);
  const [systemConfig, setSystemConfig] = useState<SystemConfig>(DEFAULT_CONFIG);

  const syncRealMatchesFromESPN = async (): Promise<{ success: boolean; message: string }> => {
    try {
      pushSystemLog('INFO', 'API', 'Iniciando sincronización con el API de ESPN...');
      
      const response = await fetch('https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard?limit=100');
      if (!response.ok) {
        throw new Error(`ESPN API returned status ${response.status}`);
      }
      
      const data = await response.json();
      const events: any[] = data.events || [];
      
      if (events.length === 0) {
        pushSystemLog('WARNING', 'API', 'Sincronización finalizada. No se encontraron eventos de la Copa del Mundo.');
        return { success: true, message: 'No se encontraron partidos de la Copa del Mundo en ESPN actualmente.' };
      }
      
      // Map and merge matches
      const currentStored = localStorage.getItem('fb_matches');
      let currentMatches: Match[] = currentStored ? JSON.parse(currentStored) : [...matches];
      if (currentMatches.length === 0) {
        currentMatches = [...INITIAL_MATCHES];
      }
      
      let newCount = 0;
      let updatedCount = 0;
      let finishedEventTriggers: Array<{ id: string; homeScore: number; awayScore: number }> = [];
      
      const getCountryFlagEmoji = (name: string): string => {
        const cleaned = name.trim();
        if (COUNTRY_FLAGS[cleaned]) return COUNTRY_FLAGS[cleaned];
        for (const key of Object.keys(COUNTRY_FLAGS)) {
          if (cleaned.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(cleaned.toLowerCase())) {
            return COUNTRY_FLAGS[key];
          }
        }
        return '⚽';
      };

      const getStageTranslation = (headline: string): string => {
        if (!headline) return 'Fase de Grupos';
        const h = headline.toLowerCase();
        if (h.includes('group') || h.includes('grupos')) return 'Fase de Grupos';
        if (h.includes('16') || h.includes('octavos')) return 'Octavos de Final';
        if (h.includes('quarter') || h.includes('cuartos')) return 'Cuartos de Final';
        if (h.includes('semi')) return 'Semifinales';
        if (h.includes('third') || h.includes('3rd') || h.includes('tercer')) return 'Tercer Puesto';
        if (h.includes('final') || h.includes('gran final')) return 'La Gran Final';
        return headline;
      };

      let nextMatches = [...currentMatches];
      
      events.forEach((ev: any) => {
        const comp = ev.competitions?.[0];
        if (!comp) return;
        
        const homeComp = comp.competitors?.find((c: any) => c.homeAway === 'home');
        const awayComp = comp.competitors?.find((c: any) => c.homeAway === 'away');
        
        if (!homeComp || !awayComp) return;
        
        const homeTeamName = homeComp.team?.displayName || homeComp.team?.name || 'Local';
        const awayTeamName = awayComp.team?.displayName || awayComp.team?.name || 'Visitante';
        const dateStr = ev.date || comp.date || new Date().toISOString();
        
        const state = ev.status?.type?.state || 'pre';
        let mappedStatus: 'PENDING' | 'LIVE' | 'FINISHED' = 'PENDING';
        if (state === 'post') mappedStatus = 'FINISHED';
        else if (state === 'in') mappedStatus = 'LIVE';
        
        const homeScoreVal = homeComp.score ? parseInt(homeComp.score) : undefined;
        const awayScoreVal = awayComp.score ? parseInt(awayComp.score) : undefined;
        
        const stageName = getStageTranslation(comp.notes?.[0]?.headline || ev.season?.slug || 'Fase de Grupos');
        const espnId = `espn_${ev.id}`;
        
        let existingIdx = nextMatches.findIndex(m => m.id === espnId);
        
        if (existingIdx === -1) {
          existingIdx = nextMatches.findIndex(m => 
            (m.homeTeam.toLowerCase() === homeTeamName.toLowerCase() && m.awayTeam.toLowerCase() === awayTeamName.toLowerCase()) ||
            (m.homeTeam.toLowerCase() === awayComp.team?.name?.toLowerCase() && m.awayTeam.toLowerCase() === homeComp.team?.name?.toLowerCase())
          );
        }
        
        const statsObj = {
          possessionHome: 50,
          possessionAway: 50,
          shotsHome: 10,
          shotsAway: 10,
          foulsHome: 10,
          foulsAway: 10
        };
        
        const matchPayload: Match = {
          id: existingIdx !== -1 ? nextMatches[existingIdx].id : espnId,
          homeTeam: homeTeamName,
          homeFlag: getCountryFlagEmoji(homeTeamName),
          awayTeam: awayTeamName,
          awayFlag: getCountryFlagEmoji(awayTeamName),
          date: dateStr,
          status: mappedStatus,
          homeScore: (mappedStatus === 'LIVE' || mappedStatus === 'FINISHED') ? homeScoreVal : undefined,
          awayScore: (mappedStatus === 'LIVE' || mappedStatus === 'FINISHED') ? awayScoreVal : undefined,
          stage: stageName,
          stats: nextMatches[existingIdx]?.stats || statsObj
        };
        
        if (existingIdx !== -1) {
          const prevMatch = nextMatches[existingIdx];
          
          if (mappedStatus === 'FINISHED' && prevMatch.status !== 'FINISHED') {
            finishedEventTriggers.push({
              id: prevMatch.id,
              homeScore: homeScoreVal ?? 0,
              awayScore: awayScoreVal ?? 0
            });
          }
          
          nextMatches[existingIdx] = {
            ...prevMatch,
            ...matchPayload,
            id: prevMatch.id
          };
          updatedCount++;
        } else {
          nextMatches.push(matchPayload);
          newCount++;
        }
      });
      
      // Apply clean merge
      setMatches(nextMatches);
      localStorage.setItem('fb_matches', JSON.stringify(nextMatches));
      
      pushSystemLog('SUCCESS', 'API', `Sincronización completada. ${newCount} nuevos partidos creados, ${updatedCount} actualizados.`);
      
      if (finishedEventTriggers.length > 0) {
        pushSystemLog('INFO', 'REWARDS', `Detectados ${finishedEventTriggers.length} partidos finalizados. Procesando recompensas...`);
        finishedEventTriggers.forEach(t => {
          adminUpdateMatch(t.id, t.homeScore, t.awayScore, 'FINISHED');
        });
      }
      
      return { 
        success: true, 
        message: `Sincronización completada: ${newCount} partidos agregados, ${updatedCount} actualizados.` 
      };
    } catch (err: any) {
      console.error(err);
      pushSystemLog('ERROR', 'API', `Error al sincronizar con ESPN: ${err.message || err}`);
      return { success: false, message: `Error al conectar con la API de ESPN: ${err.message || 'Error de red'}` };
    }
  };

  // Helper to persist entire state to backend server
  const saveStateToServerBlock = async (updates: {
    users?: User[];
    matches?: Match[];
    predictions?: Prediction[];
    promoCodes?: PromoCode[];
    pointsLogs?: PointsLog[];
    systemLogs?: SystemLog[];
    notifications?: PushNotification[];
    systemConfig?: SystemConfig;
  }) => {
    try {
      lastSaveTimeRef.current = Date.now();
      const payload = {
        users: updates.users !== undefined ? updates.users : JSON.parse(localStorage.getItem('fb_users') || JSON.stringify(INITIAL_USERS)),
        matches: updates.matches !== undefined ? updates.matches : JSON.parse(localStorage.getItem('fb_matches') || JSON.stringify(INITIAL_MATCHES)),
        predictions: updates.predictions !== undefined ? updates.predictions : JSON.parse(localStorage.getItem('fb_predictions') || '[]'),
        promoCodes: updates.promoCodes !== undefined ? updates.promoCodes : JSON.parse(localStorage.getItem('fb_codes') || JSON.stringify(INITIAL_CODES)),
        pointsLogs: updates.pointsLogs !== undefined ? updates.pointsLogs : JSON.parse(localStorage.getItem('fb_logs') || JSON.stringify(INITIAL_LOGS)),
        systemLogs: updates.systemLogs !== undefined ? updates.systemLogs : JSON.parse(localStorage.getItem('fb_sys_logs') || JSON.stringify(INITIAL_SYSTEM_LOGS)),
        notifications: updates.notifications !== undefined ? updates.notifications : JSON.parse(localStorage.getItem('fb_notifs') || '[]'),
        systemConfig: updates.systemConfig !== undefined ? updates.systemConfig : JSON.parse(localStorage.getItem('fb_config') || JSON.stringify(DEFAULT_CONFIG)),
      };

      await fetch('/api/state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (err) {
      console.error("Error saving state to server:", err);
    }
  };

  // Initialize Database and setup polling
  useEffect(() => {
    const loadStateFromServer = async () => {
      try {
        const res = await fetch('/api/state');
        const resData = await res.json();
        if (resData && !resData.empty && resData.data) {
          const d = resData.data;
          if (d.users) { setUsers(d.users); localStorage.setItem('fb_users', JSON.stringify(d.users)); }
          if (d.matches) { setMatches(d.matches); localStorage.setItem('fb_matches', JSON.stringify(d.matches)); }
          if (d.predictions) { setPredictions(d.predictions); localStorage.setItem('fb_predictions', JSON.stringify(d.predictions)); }
          if (d.promoCodes) { setPromoCodes(d.promoCodes); localStorage.setItem('fb_codes', JSON.stringify(d.promoCodes)); }
          if (d.pointsLogs) { setPointsLogs(d.pointsLogs); localStorage.setItem('fb_logs', JSON.stringify(d.pointsLogs)); }
          if (d.systemLogs) { setSystemLogs(d.systemLogs); localStorage.setItem('fb_sys_logs', JSON.stringify(d.systemLogs)); }
          if (d.notifications) { setNotifications(d.notifications); localStorage.setItem('fb_notifs', JSON.stringify(d.notifications)); }
          if (d.systemConfig) { setSystemConfig(d.systemConfig); localStorage.setItem('fb_config', JSON.stringify(d.systemConfig)); }
        } else {
          // Server DB is empty, initialize it with local values or defaults
          const initialNotifs: PushNotification[] = [
            {
              id: 'n1',
              title: '¡Bienvenido a Football Rewards!',
              body: 'Consigue puntos pronosticando partidos del Mundial y canjeando tus tiquets de compra del restaurante.',
              date: new Date().toISOString(),
              type: 'SYSTEM',
              read: false
            }
          ];
          const initialPayload = {
            users: JSON.parse(localStorage.getItem('fb_users') || JSON.stringify(INITIAL_USERS)),
            matches: JSON.parse(localStorage.getItem('fb_matches') || JSON.stringify(INITIAL_MATCHES)),
            predictions: JSON.parse(localStorage.getItem('fb_predictions') || '[]'),
            promoCodes: JSON.parse(localStorage.getItem('fb_codes') || JSON.stringify(INITIAL_CODES)),
            pointsLogs: JSON.parse(localStorage.getItem('fb_logs') || JSON.stringify(INITIAL_LOGS)),
            systemLogs: JSON.parse(localStorage.getItem('fb_sys_logs') || JSON.stringify(INITIAL_SYSTEM_LOGS)),
            notifications: JSON.parse(localStorage.getItem('fb_notifs') || JSON.stringify(initialNotifs)),
            systemConfig: JSON.parse(localStorage.getItem('fb_config') || JSON.stringify(DEFAULT_CONFIG)),
          };
          setUsers(initialPayload.users);
          setMatches(initialPayload.matches);
          setPredictions(initialPayload.predictions);
          setPromoCodes(initialPayload.promoCodes);
          setPointsLogs(initialPayload.pointsLogs);
          setSystemLogs(initialPayload.systemLogs);
          setNotifications(initialPayload.notifications);
          setSystemConfig(initialPayload.systemConfig);
          await fetch('/api/state', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(initialPayload)
          });
        }
      } catch (err) {
        console.error("Error loading state from server:", err);
        // Fallback to local storage if server fails
        const storedUsers = localStorage.getItem('fb_users');
        const storedMatches = localStorage.getItem('fb_matches');
        const storedPredictions = localStorage.getItem('fb_predictions');
        const storedCodes = localStorage.getItem('fb_codes');
        const storedLogs = localStorage.getItem('fb_logs');
        const storedSystemLogs = localStorage.getItem('fb_sys_logs');
        const storedConfig = localStorage.getItem('fb_config');
        const storedNotifications = localStorage.getItem('fb_notifs');

        if (storedUsers) setUsers(JSON.parse(storedUsers)); else setUsers(INITIAL_USERS);
        if (storedMatches) setMatches(JSON.parse(storedMatches)); else setMatches(INITIAL_MATCHES);
        if (storedPredictions) setPredictions(JSON.parse(storedPredictions)); else setPredictions([]);
        if (storedCodes) setPromoCodes(JSON.parse(storedCodes)); else setPromoCodes(INITIAL_CODES);
        if (storedLogs) setPointsLogs(JSON.parse(storedLogs)); else setPointsLogs(INITIAL_LOGS);
        if (storedSystemLogs) setSystemLogs(JSON.parse(storedSystemLogs)); else setSystemLogs(INITIAL_SYSTEM_LOGS);
        if (storedConfig) setSystemConfig(JSON.parse(storedConfig)); else setSystemConfig(DEFAULT_CONFIG);
        if (storedNotifications) setNotifications(JSON.parse(storedNotifications)); else setNotifications([]);
      }

      // Check current user
      const storedCurrentUser = localStorage.getItem('fb_current_user');
      if (storedCurrentUser) {
        setCurrentUserState(JSON.parse(storedCurrentUser));
      }
    };

    loadStateFromServer();

    // Setup periodic polling every 5 seconds to sync data across other devices
    const interval = setInterval(async () => {
      try {
        // Skip polling if there has been a local save action in the last 8 seconds
        if (Date.now() - lastSaveTimeRef.current < 8000) {
          return;
        }
        const res = await fetch('/api/state');
        if (res.ok) {
          const resData = await res.json();
          if (resData && !resData.empty && resData.data) {
            const d = resData.data;
            if (d.users) setUsers(d.users);
            if (d.matches) setMatches(d.matches);
            if (d.predictions) setPredictions(d.predictions);
            if (d.promoCodes) setPromoCodes(d.promoCodes);
            if (d.pointsLogs) setPointsLogs(d.pointsLogs);
            if (d.systemLogs) setSystemLogs(d.systemLogs);
            if (d.notifications) setNotifications(d.notifications);
            if (d.systemConfig) setSystemConfig(d.systemConfig);

            const savedCurrentUser = localStorage.getItem('fb_current_user');
            if (savedCurrentUser && d.users) {
              const parsed = JSON.parse(savedCurrentUser);
              const fresh = d.users.find((u: any) => u.id === parsed.id);
              if (fresh) {
                setCurrentUserState(fresh);
                localStorage.setItem('fb_current_user', JSON.stringify(fresh));
              }
            }
          }
        }
      } catch (pollingErr) {
        console.warn("Polling state sync error (offline?):", pollingErr);
      }
    }, 5000);

    // Auto-sync real World Cup matches from ESPN
    setTimeout(() => {
      syncRealMatchesFromESPN().catch(err => console.error("Error auto-syncing on load:", err));
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  // Update central states and persist to server
  const updateUsers = (newUsers: User[]) => {
    const sorted = [...newUsers].sort((a, b) => b.points - a.points);
    setUsers(sorted);
    localStorage.setItem('fb_users', JSON.stringify(sorted));
    
    if (currentUser) {
      const freshUser = sorted.find(u => u.id === currentUser.id);
      if (freshUser) {
        setCurrentUserState(freshUser);
        localStorage.setItem('fb_current_user', JSON.stringify(freshUser));
      }
    }
    saveStateToServerBlock({ users: sorted });
  };

  const setCurrentUser = (user: User | null) => {
    setCurrentUserState(user);
    if (user) {
      localStorage.setItem('fb_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('fb_current_user');
    }
  };

  const updateMatches = (newMatches: Match[]) => {
    setMatches(newMatches);
    localStorage.setItem('fb_matches', JSON.stringify(newMatches));
    saveStateToServerBlock({ matches: newMatches });
  };

  const updatePredictions = (newPredictions: Prediction[]) => {
    setPredictions(newPredictions);
    localStorage.setItem('fb_predictions', JSON.stringify(newPredictions));
    saveStateToServerBlock({ predictions: newPredictions });
  };

  const updatePromoCodes = (newCodes: PromoCode[]) => {
    setPromoCodes(newCodes);
    localStorage.setItem('fb_codes', JSON.stringify(newCodes));
    saveStateToServerBlock({ promoCodes: newCodes });
  };

  const updatePointsLogs = (newLogs: PointsLog[]) => {
    setPointsLogs(newLogs);
    localStorage.setItem('fb_logs', JSON.stringify(newLogs));
    saveStateToServerBlock({ pointsLogs: newLogs });
  };

  const pushSystemLog = (type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR', module: 'AUTH' | 'DATABASE' | 'OTP' | 'API' | 'ADMIN' | 'REWARDS', message: string) => {
    const newLog: SystemLog = {
      id: 'sys_' + Date.now() + Math.random().toString(36).substring(2, 5),
      timestamp: new Date().toISOString(),
      type,
      module,
      message
    };
    const updated = [newLog, ...systemLogs].slice(0, 100);
    setSystemLogs(updated);
    localStorage.setItem('fb_sys_logs', JSON.stringify(updated));
    saveStateToServerBlock({ systemLogs: updated });
  };

  const pushNotification = (title: string, body: string, type: 'MATCH' | 'POINTS' | 'RANKING' | 'SYSTEM') => {
    const newNotif: PushNotification = {
      id: 'notif_' + Date.now() + Math.random().toString(36).substring(2, 5),
      title,
      body,
      date: new Date().toISOString(),
      type,
      read: false
    };
    const updated = [newNotif, ...notifications];
    setNotifications(updated);
    localStorage.setItem('fb_notifs', JSON.stringify(updated));
    saveStateToServerBlock({ notifications: updated });
  };

  // ----- AUTH FLOW -----
  const sendOtp = (name: string, phone: string) => {
    // Generate simple readable 4-digit code e.g. "5082"
    const otpCode = Math.floor(1000 + Math.random() * 9000).toString();
    pushSystemLog('SUCCESS', 'OTP', `Código OTP generado [${otpCode}] enviado para ${name} al teléfono ${phone}`);
    
    // Simulate push alert representing the SMS arrival
    pushNotification('🔑 Código OTP Recibido', `Tu código de verificación de Football Rewards es: ${otpCode}`, 'SYSTEM');
    
    return { success: true, code: otpCode };
  };

  const verifyOtp = (phone: string, name: string, code: string) => {
    if (!code || code === '') {
      return { success: false, error: 'Código de verificación requerido.' };
    }

    pushSystemLog('INFO', 'AUTH', `Intento de inicio de sesión de usuario ${name} con teléfono ${phone}`);
    
    // Look for existing user
    let user = users.find(u => u.phone === phone);
    
    if (user) {
      if (!user.active) {
        pushSystemLog('WARNING', 'AUTH', `Intento de acceso de usuario bloqueado: ${user.name}`);
        return { success: false, error: 'Tu cuenta ha sido suspendida. Contacta al administrador.' };
      }
      pushSystemLog('SUCCESS', 'AUTH', `Usuario existente verificado con éxito: ${user.name}`);
    } else {
      // Create new user
      const newUser: User = {
        id: 'u_' + Date.now().toString(),
        name,
        phone,
        registerDate: new Date().toISOString(),
        points: 0,
        pointsFromPredictions: 0,
        pointsFromPurchases: 0,
        active: true,
        streak: 0,
        maxStreak: 0,
        hitsCount: 0,
        missesCount: 0,
        predictionsCount: 0
      };
      
      const updated = [...users, newUser];
      updateUsers(updated);
      user = newUser;
      pushSystemLog('SUCCESS', 'AUTH', `Nuevo usuario registrado automáticamente: ${name}`);
    }

    setCurrentUser(user);
    pushNotification('🎖️ ¡Bienvenido!', `Hola ${user.name}, ¡empecemos a acumular puntos!`, 'SYSTEM');
    return { success: true, user };
  };

  const logout = () => {
    pushSystemLog('INFO', 'AUTH', `Sesión finalizada para el usuario: ${currentUser?.name}`);
    setCurrentUser(null);
  };

  // ----- SYSTEM GAMEPLAY ACTIONS -----
  
  // Place prediction (+10 pts points automatically)
  const placePrediction = (matchId: string, predictedWinner: 'LOCAL' | 'DRAW' | 'AWAY', homeScore: number, awayScore: number) => {
    if (!currentUser) {
      return { success: false, message: 'Se requiere iniciar sesión.' };
    }

    const match = matches.find(m => m.id === matchId);
    if (!match) {
      return { success: false, message: 'Partido no encontrado.' };
    }

    if (match.status !== 'PENDING') {
      return { success: false, message: 'Los pronósticos están cerrados para este partido.' };
    }

    // Check if user already predicted it
    const existingIndex = predictions.findIndex(p => p.userId === currentUser.id && p.matchId === matchId);
    
    let isEditing = existingIndex >= 0;
    let pointsBonus = 0;

    let updatedPredictions = [...predictions];
    
    if (isEditing) {
      // Update existing
      updatedPredictions[existingIndex] = {
        ...updatedPredictions[existingIndex],
        predictedWinner,
        predictedHomeScore: homeScore,
        predictedAwayScore: awayScore
      };
      pushSystemLog('INFO', 'DATABASE', `Pronóstico actualizado por ${currentUser.name} para ${match.homeTeam} vs ${match.awayTeam}`);
    } else {
      // New prediction
      const newPred: Prediction = {
        id: 'p_' + Date.now().toString(),
        userId: currentUser.id,
        matchId,
        predictedWinner,
        predictedHomeScore: homeScore,
        predictedAwayScore: awayScore,
        status: 'PENDING',
        pointsAwarded: 0
      };
      
      updatedPredictions.push(newPred);
      pointsBonus = 10; // +10 points participation
      pushSystemLog('SUCCESS', 'DATABASE', `Nuevo pronóstico realizado por ${currentUser.name} para ${match.homeTeam} vs ${match.awayTeam}`);
    }

    updatePredictions(updatedPredictions);

    if (pointsBonus > 0) {
      // Award participation points immediately
      const updatedUser: User = {
        ...currentUser,
        points: currentUser.points + pointsBonus,
        pointsFromPredictions: currentUser.pointsFromPredictions + pointsBonus,
        predictionsCount: currentUser.predictionsCount + 1
      };

      // update in users list
      const updatedUsersList = users.map(u => u.id === currentUser.id ? updatedUser : u);
      updateUsers(updatedUsersList);

      // Log points movement
      const newLog: PointsLog = {
        id: 'l_' + Date.now().toString(),
        userId: currentUser.id,
        type: 'PREDICTION_PARTICIPATION',
        points: pointsBonus,
        date: new Date().toISOString(),
        description: `Participación en pronóstico: ${match.homeTeam} vs ${match.awayTeam}`,
        referenceId: matchId
      };
      updatePointsLogs([newLog, ...pointsLogs]);
      pushNotification('⚽ Pronóstico Registrado', `Has sumado +10 puntos por pronosticar en ${match.homeTeam} vs ${match.awayTeam}`, 'POINTS');
    }

    return { success: true, message: isEditing ? 'Pronóstico modificado exitosamente.' : '¡Pronóstico registrado! Has ganado +10 puntos.' };
  };

  // Redeem Promo/Points codes
  const claimPromoCode = (codeStr: string) => {
    if (!currentUser) {
      return { success: false, message: 'Se requiere iniciar sesión.' };
    }

    const trimmed = codeStr.trim().toUpperCase();
    const codeObj = promoCodes.find(c => c.code === trimmed);

    if (!codeObj) {
      pushSystemLog('WARNING', 'REWARDS', `Intento de reclamo fallido por código inexistente: "${trimmed}" por ${currentUser.name}`);
      return { success: false, message: 'Código inválido o inexistente.' };
    }

    if (!codeObj.active) {
      pushSystemLog('WARNING', 'REWARDS', `Intento de reclamo de código inactivo: "${trimmed}" por ${currentUser.name}`);
      return { success: false, message: 'Este código ha sido desactivado por el administrador.' };
    }

    // Check expiration
    const expiry = new Date(codeObj.expirationDate + 'T23:59:59');
    if (expiry < new Date()) {
      pushSystemLog('WARNING', 'REWARDS', `Código expirado: "${trimmed}" (fecha exp: ${codeObj.expirationDate})`);
      return { success: false, message: 'Este código ya ha expirado.' };
    }

    // Check maximum uses
    if (codeObj.usedCount >= codeObj.maxUses) {
      pushSystemLog('WARNING', 'REWARDS', `Límite de usos alcanzado para: "${trimmed}" (${codeObj.usedCount}/${codeObj.maxUses})`);
      return { success: false, message: 'Este código ya alcanzó su límite máximo de canjes.' };
    }

    // Check if user already claimed this specific code
    const alreadyClaimed = codeObj.claims.some(claim => claim.userId === currentUser.id);
    if (alreadyClaimed) {
      pushSystemLog('WARNING', 'REWARDS', `El usuario ${currentUser.name} intentó redimir un código ya reclamado: "${trimmed}"`);
      return { success: false, message: 'Ya has reclamado este código de puntos anteriormente.' };
    }

    // Valid code! Process claim
    const pointsAwarded = codeObj.points;
    
    // 1. Add claim to code
    const updatedCodes = promoCodes.map(c => {
      if (c.id === codeObj.id) {
        return {
          ...c,
          usedCount: c.usedCount + 1,
          claims: [...c.claims, { userId: currentUser.id, userName: currentUser.name, date: new Date().toISOString() }]
        };
      }
      return c;
    });
    updatePromoCodes(updatedCodes);

    // 2. Award points to user
    const updatedUser: User = {
      ...currentUser,
      points: currentUser.points + pointsAwarded,
      pointsFromPurchases: currentUser.pointsFromPurchases + pointsAwarded
    };
    const updatedUsersList = users.map(u => u.id === currentUser.id ? updatedUser : u);
    updateUsers(updatedUsersList);

    // 3. Log Points movement
    const newLog: PointsLog = {
      id: 'l_' + Date.now().toString(),
      userId: currentUser.id,
      type: 'PURCHASE_CODE',
      points: pointsAwarded,
      date: new Date().toISOString(),
      description: `Canje de tiquete: Código ${trimmed} por consumo de $${codeObj.purchaseValue.toLocaleString()}`,
      referenceId: trimmed
    };
    updatePointsLogs([newLog, ...pointsLogs]);

    pushSystemLog('SUCCESS', 'REWARDS', `Código de puntos canjeado con éxito: "${trimmed}" por ${currentUser.name} (+${pointsAwarded} pts)`);
    pushNotification('🎁 Puntos Canjeados', `Felicidades, has sumado +${pointsAwarded} puntos de tu tiquete de consumo.`, 'POINTS');

    return { success: true, message: `¡Código redimido! Se han acreditado +${pointsAwarded} puntos a tu cuenta.`, pointsAwarded };
  };

  // ----- ADMIN ACTIONS -----
  const adminCreateCode = (code: string, purchaseValue: number, points: number, expirationDate: string, maxUses: number) => {
    const trimmedCode = code.toUpperCase().trim();
    if (promoCodes.some(c => c.code === trimmedCode)) {
      return { success: false, message: 'Ya existe un código con esa misma nomenclatura.' };
    }

    const newCode: PromoCode = {
      id: 'c_' + Date.now().toString(),
      code: trimmedCode,
      purchaseValue,
      points,
      expirationDate,
      maxUses,
      usedCount: 0,
      active: true,
      claims: []
    };

    updatePromoCodes([...promoCodes, newCode]);
    pushSystemLog('SUCCESS', 'ADMIN', `Administrador creó el código promocional "${trimmedCode}" por +${points} puntos`);
    return { success: true, message: `Código de puntos ${trimmedCode} generado exitosamente.` };
  };

  const adminToggleCodeStatus = (codeId: string) => {
    const updatedCodes = promoCodes.map(c => {
      if (c.id === codeId) {
        const nextState = !c.active;
        pushSystemLog('INFO', 'ADMIN', `Estado de código "${c.code}" cambiado a: ${nextState ? 'ACTIVO' : 'INACTIVO'}`);
        return { ...c, active: nextState };
      }
      return c;
    });
    updatePromoCodes(updatedCodes);
  };

  const adminDeleteCode = (codeId: string) => {
    const code = promoCodes.find(c => c.id === codeId);
    if (!code) return;
    updatePromoCodes(promoCodes.filter(c => c.id !== codeId));
    pushSystemLog('WARNING', 'ADMIN', `Código de puntos eliminado: "${code.code}"`);
  };

  const adminUpdateConfig = (config: SystemConfig) => {
    setSystemConfig(config);
    localStorage.setItem('fb_config', JSON.stringify(config));
    pushSystemLog('SUCCESS', 'ADMIN', 'Configuración de recompensas y tasación de consumo modificados.');
  };

  const adminToggleUserBlock = (userId: string) => {
    const updated = users.map(u => {
      if (u.id === userId) {
        const nextState = !u.active;
        pushSystemLog('WARNING', 'ADMIN', `Estado de bloqueo del usuario "${u.name}" cambiado a: ${nextState ? 'Habilitado' : 'PROGRAMA_BLOQUEADO'}`);
        return { ...u, active: nextState };
      }
      return u;
    });
    updateUsers(updated);
  };

  const adminDeleteUser = (userId: string) => {
    const userObj = users.find(u => u.id === userId);
    if (!userObj) return;
    updateUsers(users.filter(u => u.id !== userId));
    pushSystemLog('ERROR', 'ADMIN', `Usuario eliminado de forma permanente: "${userObj.name}"`);
    if (currentUser?.id === userId) {
      setCurrentUser(null);
    }
  };

  const adminTriggerNotification = (title: string, body: string, type: 'MATCH' | 'POINTS' | 'RANKING' | 'SYSTEM') => {
    pushNotification(title, body, type);
    pushSystemLog('INFO', 'ADMIN', `Campaña de notificación push enviada a todos los dispositivos: "${title}"`);
  };

  const adminAddMatch = (matchData: Omit<Match, "id">) => {
    const newId = 'm_' + Date.now().toString() + Math.random().toString(36).substring(2, 5);
    const newMatch: Match = {
      ...matchData,
      id: newId
    };
    const nextMatches = [newMatch, ...matches];
    updateMatches(nextMatches);
    pushSystemLog('SUCCESS', 'ADMIN', `Nuevo partido agregado: ${matchData.homeTeam} vs ${matchData.awayTeam}`);
  };

  const adminDeleteMatch = (matchId: string) => {
    const matchObj = matches.find(m => m.id === matchId);
    if (!matchObj) return;
    const nextMatches = matches.filter(m => m.id !== matchId);
    updateMatches(nextMatches);
    pushSystemLog('ERROR', 'ADMIN', `Partido eliminado con éxito: ${matchObj.homeTeam} vs ${matchObj.awayTeam}`);
  };

  const adminUpdateUserPoints = (userId: string, points: number, pointsFromPredictions?: number, pointsFromPurchases?: number) => {
    const userObj = users.find(u => u.id === userId);
    if (!userObj) return;
    const updated = users.map(u => {
      if (u.id === userId) {
        return {
          ...u,
          points,
          pointsFromPredictions: pointsFromPredictions !== undefined ? pointsFromPredictions : u.pointsFromPredictions,
          pointsFromPurchases: pointsFromPurchases !== undefined ? pointsFromPurchases : u.pointsFromPurchases
        };
      }
      return u;
    });
    updateUsers(updated);
    pushSystemLog('SUCCESS', 'ADMIN', `Se modificó manualmente el puntaje de ${userObj.name} a ${points} pts.`);
  };

  // Administrative Match Simulator Game updates
  // THIS IS THE BRAIN OF DYNAMIC REALTIME REWARDS AWARDING
  const adminUpdateMatch = (matchId: string, homeScore: number, awayScore: number, status: 'PENDING' | 'LIVE' | 'FINISHED') => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return;

    const matchUpdated: Match = {
      ...match,
      homeScore,
      awayScore,
      status
    };

    const updatedMatchesList = matches.map(m => m.id === matchId ? matchUpdated : m);
    updateMatches(updatedMatchesList);
    pushSystemLog('INFO', 'API', `Simulando actualización de partido: ${match.homeTeam} vs ${match.awayTeam} -> marcador: [${homeScore}-${awayScore}] Estado: [${status}]`);

    // If game has just been FINISHED, recalculate all scores & award points!
    if (status === 'FINISHED' && match.status !== 'FINISHED') {
      pushSystemLog('INFO', 'REWARDS', `Procesando puntos para pronósticos del partido finalizado: ${match.homeTeam} vs ${match.awayTeam}`);
      
      const realOutcome: 'LOCAL' | 'DRAW' | 'AWAY' = homeScore > awayScore ? 'LOCAL' : awayScore > homeScore ? 'AWAY' : 'DRAW';

      // Load all predictions for this match
      let updatedPredictionsList = [...predictions];
      let mutableUsers = [...users];
      let newLogsList: PointsLog[] = [];

      // Find all predictions placed for this match
      const matchPreds = predictions.filter(p => p.matchId === matchId && p.status === 'PENDING');

      if (matchPreds.length === 0) {
        pushSystemLog('INFO', 'REWARDS', `No se registraron pronósticos pendientes para este partido.`);
      }

      matchPreds.forEach(pred => {
        let outcomeCorrect = pred.predictedWinner === realOutcome;
        let scoreCorrect = pred.predictedHomeScore === homeScore && pred.predictedAwayScore === awayScore;

        let points = 0;
        let pStatus: 'CORRECT_EXACT' | 'CORRECT_OUTCOME' | 'INCORRECT' = 'INCORRECT';

        if (scoreCorrect) {
          // Exact Match Success (+100 pts)
          points = 100;
          pStatus = 'CORRECT_EXACT';
        } else if (outcomeCorrect) {
          // Correct victor, incorrect score (+50 pts)
          points = 50;
          pStatus = 'CORRECT_OUTCOME';
        }

        // Update prediction status & points in memory
        updatedPredictionsList = updatedPredictionsList.map(p => {
          if (p.id === pred.id) {
            return { ...p, status: pStatus, pointsAwarded: points };
          }
          return p;
        });

        // Award points to the corresponding user in the mutable ranking array
        const userIndex = mutableUsers.findIndex(u => u.id === pred.userId);
        if (userIndex >= 0) {
          const userObj = mutableUsers[userIndex];
          const hasHit = pStatus !== 'INCORRECT';

          // Calculate Streak logic
          let userNewStreak = hasHit ? userObj.streak + 1 : 0;
          let userNewMaxStreak = Math.max(userObj.maxStreak, userNewStreak);
          let extraPointsBonus = 0;
          let bonusLogs: PointsLog[] = [];

          // Streak Bonus Triggers:
          if (userNewStreak === 3) {
            extraPointsBonus += 75;
            bonusLogs.push({
              id: 'streak_log_' + Date.now() + Math.random().toString(36).substring(2, 4),
              userId: userObj.id,
              type: 'PREDICTION_BONUS_3',
              points: 75,
              date: new Date().toISOString(),
              description: `⭐ ¡Bono de Racha Deportiva! 3 aciertos consecutivos (+75 pts)`,
              referenceId: matchId
            });
            pushSystemLog('SUCCESS', 'REWARDS', `¡Racha de 3 aciertos consecutivos de ${userObj.name}! Activando +75 pts bono.`);
            // if this is the active user, trigger live push
            if (currentUser && userObj.id === currentUser.id) {
              pushNotification('🔥 ¡Racha de Fuego!', `¡Impresionante! 3 aciertos seguidos sumándote bono de +75 puntos.`, 'POINTS');
            }
          } else if (userNewStreak === 5) {
            extraPointsBonus += 150;
            bonusLogs.push({
              id: 'streak_log_' + Date.now() + Math.random().toString(36).substring(2, 4),
              userId: userObj.id,
              type: 'PREDICTION_BONUS_5',
              points: 150,
              date: new Date().toISOString(),
              description: `🔥 ¡Bono de Racha Perfecta! 5 aciertos consecutivos (+150 pts)`,
              referenceId: matchId
            });
            pushSystemLog('SUCCESS', 'REWARDS', `¡Racha de 5 aciertos consecutivos de ${userObj.name}! Activando +150 pts bono.`);
            if (currentUser && userObj.id === currentUser.id) {
              pushNotification('🏆 ¡Racha Perfecta!', `¡No te para nadie! 5 aciertos seguidos sumándote un superbono de +150 puntos.`, 'POINTS');
            }
          }

          // Main result Points log
          if (points > 0) {
            const resultMsg = pStatus === 'CORRECT_EXACT' ? 'Marcador exacto' : 'Ganador correcto';
            newLogsList.push({
              id: 'l_res_' + Date.now() + Math.random().toString(36).substring(2, 4),
              userId: userObj.id,
              type: pStatus === 'CORRECT_EXACT' ? 'PREDICTION_EXACT' : 'PREDICTION_OUTCOME',
              points: points,
              date: new Date().toISOString(),
              description: `Resultado de pronóstico para ${match.homeTeam} vs ${match.awayTeam} (${resultMsg}: +${points} pts)`,
              referenceId: matchId
            });

            if (currentUser && userObj.id === currentUser.id) {
              pushNotification('📢 ¡Pronóstico Acertado!', `Adivinaste el partido de ${match.homeTeam} vs ${match.awayTeam} y recibiste +${points} puntos.`, 'POINTS');
            }
          }

          // Combine bonus logs
          if (bonusLogs.length > 0) {
            newLogsList = [...bonusLogs, ...newLogsList];
          }

          // Update user fields
          mutableUsers[userIndex] = {
            ...userObj,
            points: userObj.points + points + extraPointsBonus,
            pointsFromPredictions: userObj.pointsFromPredictions + points + extraPointsBonus,
            streak: userNewStreak,
            maxStreak: userNewMaxStreak,
            hitsCount: userObj.hitsCount + (hasHit ? 1 : 0),
            missesCount: userObj.missesCount + (!hasHit ? 1 : 0)
          };
        }
      });

      // Update calculations
      updatePredictions(updatedPredictionsList);
      updateUsers(mutableUsers);
      
      if (newLogsList.length > 0) {
        updatePointsLogs([...newLogsList, ...pointsLogs]);
      }

      pushSystemLog('SUCCESS', 'REWARDS', `Finalizado procesamiento de puntos. Ranking actualizado.`);
      pushNotification('⚽ Partido Concluido', `Resultados listos para ${match.homeTeam} vs ${match.awayTeam} (${homeScore}-${awayScore}). Revisa tu posición en el ranking general.`, 'MATCH');
    }
  };

  // ----- CALCULATED LEADERBOARD MECHANICS -----
  const getLeaderboardStats = () => {
    // top 10 users list
    const top10 = users.slice(0, systemConfig.positionsRewarded);
    
    let userRank = -1;
    let pointsToTop10 = 0;
    let pointsToLeader = 0;
    let distanceToLeader = 0;

    if (currentUser) {
      userRank = users.findIndex(u => u.id === currentUser.id) + 1;
      
      const leader = users[0];
      if (leader) {
        pointsToLeader = Math.max(0, leader.points - currentUser.points);
        distanceToLeader = pointsToLeader;
      }

      const tenth = users[Math.min(users.length - 1, systemConfig.positionsRewarded - 1)];
      if (tenth) {
        pointsToTop10 = Math.max(0, tenth.points - currentUser.points);
      }
    }

    return {
      top10,
      userRank,
      pointsToTop10,
      pointsToLeader,
      distanceToLeader
    };
  };

  const getCalculatedBadges = (userId: string) => {
    const userObj = users.find(u => u.id === userId);
    if (!userObj) return [];

    const activeBadges: Badge[] = [];
    const rankingIndex = users.findIndex(u => u.id === userId);

    // Badge 1: First outcome guess hit
    if (userObj.hitsCount > 0) {
      const bOption = BADGES.find(b => b.category === 'first_hit');
      if (bOption) activeBadges.push({ ...bOption });
    }

    // Badge 2: 5 consecutive streak
    if (userObj.maxStreak >= 5) {
      const bOption = BADGES.find(b => b.category === 'streak_5');
      if (bOption) activeBadges.push({ ...bOption });
    }

    // Badge 3: Active user (more than 5 predictions)
    if (userObj.predictionsCount >= 5) {
      const bOption = BADGES.find(b => b.category === 'active_user');
      if (bOption) activeBadges.push({ ...bOption });
    }

    // Badge 4: Top 10 ranking list member
    if (rankingIndex >= 0 && rankingIndex < systemConfig.positionsRewarded) {
      const bOption = BADGES.find(b => b.category === 'top_10');
      if (bOption) activeBadges.push({ ...bOption });
    }

    // Badge 5: Podio (Top 3 ranking list)
    if (rankingIndex >= 0 && rankingIndex < 3) {
      const bOption = BADGES.find(b => b.category === 'top_3');
      if (bOption) activeBadges.push({ ...bOption });
    }

    // Badge 6: Tournament Leader
    if (rankingIndex === 0 && userObj.points > 0) {
      const bOption = BADGES.find(b => b.category === 'leader');
      if (bOption) activeBadges.push({ ...bOption });
    }

    return activeBadges;
  };

  const isAdmin = currentUser 
    ? (currentUser.name.toLowerCase() === 'admin' || 
       currentUser.name.toLowerCase() === 'administrador' || 
       currentUser.phone.toLowerCase() === 'admin' || 
       currentUser.phone === '999') 
    : false;

  return (
    <StateContext.Provider value={{
      activeRole,
      setActiveRole,
      currentUser,
      setCurrentUser,
      isAdmin,
      users,
      matches,
      predictions,
      promoCodes,
      pointsLogs,
      systemLogs,
      notifications,
      systemConfig,
      badges: BADGES,
      sendOtp,
      verifyOtp,
      logout,
      placePrediction,
      claimPromoCode,
      adminCreateCode,
      adminToggleCodeStatus,
      adminDeleteCode,
      adminUpdateMatch,
      adminUpdateConfig,
      adminToggleUserBlock,
      adminDeleteUser,
      adminTriggerNotification,
      adminAddMatch,
      adminDeleteMatch,
      adminUpdateUserPoints,
      getLeaderboardStats,
      getCalculatedBadges,
      syncRealMatchesFromESPN
    }}>
      {children}
    </StateContext.Provider>
  );
};

export const useAppState = () => {
  const context = useContext(StateContext);
  if (context === undefined) {
    throw new Error('useAppState must be used within a StateProvider');
  }
  return context;
};
