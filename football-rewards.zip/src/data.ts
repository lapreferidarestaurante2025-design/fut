import { Match, User, Badge, SystemConfig, PromoCode, PointsLog, SystemLog } from './types';

export const INITIAL_MATCHES: Match[] = [
  {
    id: 'm1',
    homeTeam: 'Argentina',
    homeFlag: '🇦🇷',
    awayTeam: 'Francia',
    awayFlag: '🇫🇷',
    date: '2026-06-15T15:00:00Z',
    status: 'PENDING',
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 52,
      possessionAway: 48,
      shotsHome: 12,
      shotsAway: 10,
      foulsHome: 11,
      foulsAway: 14
    }
  },
  {
    id: 'm2',
    homeTeam: 'España',
    homeFlag: '🇪🇸',
    awayTeam: 'Alemania',
    awayFlag: '🇩🇪',
    date: '2026-06-16T18:00:00Z',
    status: 'PENDING',
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 60,
      possessionAway: 40,
      shotsHome: 15,
      shotsAway: 9,
      foulsHome: 8,
      foulsAway: 12
    }
  },
  {
    id: 'm3',
    homeTeam: 'Brasil',
    homeFlag: '🇧🇷',
    awayTeam: 'Colombia',
    awayFlag: '🇨🇴',
    date: '2026-06-12T13:00:00Z', // Today or recent
    status: 'LIVE',
    homeScore: 2,
    awayScore: 1,
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 54,
      possessionAway: 46,
      shotsHome: 14,
      shotsAway: 11,
      foulsHome: 15,
      foulsAway: 13
    }
  },
  {
    id: 'm4',
    homeTeam: 'Inglaterra',
    homeFlag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    awayTeam: 'Estados Unidos',
    awayFlag: '🇺🇸',
    date: '2026-06-14T20:00:00Z',
    status: 'PENDING',
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 58,
      possessionAway: 42,
      shotsHome: 11,
      shotsAway: 7,
      foulsHome: 9,
      foulsAway: 10
    }
  },
  {
    id: 'm5',
    homeTeam: 'Portugal',
    homeFlag: '🇵🇹',
    awayTeam: 'Uruguay',
    awayFlag: '🇺🇾',
    date: '2026-06-11T12:00:00Z',
    status: 'FINISHED',
    homeScore: 2,
    awayScore: 0,
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 55,
      possessionAway: 45,
      shotsHome: 13,
      shotsAway: 10,
      foulsHome: 10,
      foulsAway: 16
    }
  },
  {
    id: 'm6',
    homeTeam: 'México',
    homeFlag: '🇲🇽',
    awayTeam: 'Japón',
    awayFlag: '🇯🇵',
    date: '2026-06-10T16:00:00Z',
    status: 'FINISHED',
    homeScore: 1,
    awayScore: 1,
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 47,
      possessionAway: 53,
      shotsHome: 8,
      shotsAway: 12,
      foulsHome: 12,
      foulsAway: 9
    }
  },
  {
    id: 'm7',
    homeTeam: 'Bélgica',
    homeFlag: '🇧🇪',
    awayTeam: 'Marruecos',
    awayFlag: '🇲🇦',
    date: '2026-06-09T14:00:00Z',
    status: 'FINISHED',
    homeScore: 0,
    awayScore: 2,
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 62,
      possessionAway: 38,
      shotsHome: 10,
      shotsAway: 11,
      foulsHome: 14,
      foulsAway: 18
    }
  },
  {
    id: 'm8',
    homeTeam: 'Croacia',
    homeFlag: '🇭🇷',
    awayTeam: 'Canadá',
    awayFlag: '🇨🇦',
    date: '2026-06-08T17:00:00Z',
    status: 'FINISHED',
    homeScore: 4,
    awayScore: 1,
    stage: 'Fase de Grupos',
    stats: {
      possessionHome: 49,
      possessionAway: 51,
      shotsHome: 16,
      shotsAway: 8,
      foulsHome: 11,
      foulsAway: 13
    }
  }
];

export const INITIAL_USERS: User[] = [
  {
    id: 'u1',
    name: 'Carlos "El Pibe" Valderrama',
    phone: '+57 300 123 4567',
    registerDate: '2026-06-01T10:00:00Z',
    points: 730,
    pointsFromPredictions: 430,
    pointsFromPurchases: 300,
    active: true,
    streak: 4,
    maxStreak: 6,
    hitsCount: 7,
    missesCount: 1,
    predictionsCount: 8
  },
  {
    id: 'u2',
    name: 'Mateo Restrepo',
    phone: '+57 312 987 6543',
    registerDate: '2026-06-02T11:00:00Z',
    points: 620,
    pointsFromPredictions: 320,
    pointsFromPurchases: 300,
    active: true,
    streak: 2,
    maxStreak: 3,
    hitsCount: 5,
    missesCount: 3,
    predictionsCount: 8
  },
  {
    id: 'u3',
    name: 'James Rodríguez',
    phone: '+57 310 555 4433',
    registerDate: '2026-06-03T15:30:00Z',
    points: 580,
    pointsFromPredictions: 280,
    pointsFromPurchases: 300,
    active: true,
    streak: 0,
    maxStreak: 4,
    hitsCount: 4,
    missesCount: 4,
    predictionsCount: 8
  },
  {
    id: 'u4',
    name: 'Carolina Gómez',
    phone: '+57 321 444 8899',
    registerDate: '2026-06-04T09:15:00Z',
    points: 490,
    pointsFromPredictions: 290,
    pointsFromPurchases: 200,
    active: true,
    streak: 1,
    maxStreak: 3,
    hitsCount: 4,
    missesCount: 2,
    predictionsCount: 6
  },
  {
    id: 'u5',
    name: 'Andrés Escobar',
    phone: '+57 315 222 1100',
    registerDate: '2026-06-04T14:45:00Z',
    points: 410,
    pointsFromPredictions: 260,
    pointsFromPurchases: 150,
    active: true,
    streak: 3,
    maxStreak: 3,
    hitsCount: 4,
    missesCount: 1,
    predictionsCount: 5
  },
  {
    id: 'u6',
    name: 'Sofía Vergara',
    phone: '+57 305 777 9900',
    registerDate: '2026-06-05T18:22:00Z',
    points: 390,
    pointsFromPredictions: 190,
    pointsFromPurchases: 200,
    active: true,
    streak: 1,
    maxStreak: 2,
    hitsCount: 3,
    missesCount: 3,
    predictionsCount: 6
  },
  {
    id: 'u7',
    name: 'Luis Díaz',
    phone: '+57 318 666 4455',
    registerDate: '2026-06-06T08:00:00Z',
    points: 350,
    pointsFromPredictions: 250,
    pointsFromPurchases: 100,
    active: true,
    streak: 0,
    maxStreak: 2,
    hitsCount: 4,
    missesCount: 2,
    predictionsCount: 6
  },
  {
    id: 'u8',
    name: 'Daniela Ospina',
    phone: '+57 311 333 7788',
    registerDate: '2026-06-06T12:00:00Z',
    points: 310,
    pointsFromPredictions: 160,
    pointsFromPurchases: 150,
    active: true,
    streak: 2,
    maxStreak: 3,
    hitsCount: 3,
    missesCount: 2,
    predictionsCount: 5
  },
  {
    id: 'u9',
    name: 'Radamel Falcao',
    phone: '+57 321 000 9999',
    registerDate: '2026-06-07T11:10:00Z',
    points: 290,
    pointsFromPredictions: 190,
    pointsFromPurchases: 100,
    active: true,
    streak: 1,
    maxStreak: 2,
    hitsCount: 3,
    missesCount: 1,
    predictionsCount: 4
  },
  {
    id: 'u10',
    name: 'Isabella Santo',
    phone: '+57 313 444 5555',
    registerDate: '2026-06-07T16:30:00Z',
    points: 240,
    pointsFromPredictions: 140,
    pointsFromPurchases: 100,
    active: true,
    streak: 0,
    maxStreak: 2,
    hitsCount: 2,
    missesCount: 3,
    predictionsCount: 5
  },
  {
    id: 'u11',
    name: 'Santiago Botero',
    phone: '+57 316 777 8888',
    registerDate: '2026-06-08T09:00:00Z',
    points: 180,
    pointsFromPredictions: 130,
    pointsFromPurchases: 50,
    active: true,
    streak: 2,
    maxStreak: 2,
    hitsCount: 2,
    missesCount: 2,
    predictionsCount: 4
  },
  {
    id: 'u12',
    name: 'Mariana Pajón',
    phone: '+57 317 888 9999',
    registerDate: '2026-06-08T14:15:00Z',
    points: 120,
    pointsFromPredictions: 70,
    pointsFromPurchases: 50,
    active: true,
    streak: 1,
    maxStreak: 1,
    hitsCount: 1,
    missesCount: 2,
    predictionsCount: 3
  }
];

export const BADGES: Badge[] = [
  {
    id: 'b1',
    title: 'Primer Acierto',
    description: 'Adivinaste correctamente el resultado de un partido del Mundial.',
    icon: 'Award',
    category: 'first_hit'
  },
  {
    id: 'b2',
    title: 'La Racha Perfecta',
    description: 'Alcanzaste una racha de 5 aciertos consecutivos.',
    icon: 'Flame',
    category: 'streak_5'
  },
  {
    id: 'b3',
    title: 'Mundialista Activo',
    description: 'Has realizado al menos 5 predicciones en el torneo.',
    icon: 'UserCheck',
    category: 'active_user'
  },
  {
    id: 'b4',
    title: 'Miembro del Top 10',
    description: 'Entraste a la prestigiosa lista de los 10 mejores del Mundial.',
    icon: 'TrendingUp',
    category: 'top_10'
  },
  {
    id: 'b5',
    title: 'Podio Sagrado',
    description: 'Llegaste a ocupar una de las tres mejores posiciones (Top 3).',
    icon: 'Sparkles',
    category: 'top_3'
  },
  {
    id: 'b6',
    title: 'Líder Absoluto',
    description: 'Alcanzaste el primer lugar del ranking general del Mundial.',
    icon: 'Crown',
    category: 'leader'
  }
];

export const DEFAULT_CONFIG: SystemConfig = {
  pointsPerAmountSpent: 1,
  amountMultiplierStep: 1000, // 1 point per $1000 COP
  discountFirst: 50,
  discountSecond: 40,
  discountThird: 30,
  discountOthers4to10: 15,
  positionsRewarded: 10
};

export const INITIAL_CODES: PromoCode[] = [
  {
    id: 'c1',
    code: 'GOL-73KXA',
    purchaseValue: 50000,
    points: 50,
    expirationDate: '2026-12-31',
    maxUses: 1,
    usedCount: 0,
    active: true,
    claims: []
  },
  {
    id: 'c2',
    code: 'MUNDIAL-100K',
    purchaseValue: 100000,
    points: 100,
    expirationDate: '2026-12-31',
    maxUses: 1,
    usedCount: 0,
    active: true,
    claims: []
  },
  {
    id: 'c3',
    code: 'REWARD-FREE',
    purchaseValue: 30000,
    points: 30,
    expirationDate: '2026-06-30',
    maxUses: 5,
    usedCount: 1,
    active: true,
    claims: [
      {
        userId: 'u2',
        userName: 'Mateo Restrepo',
        date: '2026-06-10T12:00:00Z'
      }
    ]
  }
];

export const INITIAL_LOGS: PointsLog[] = [
  {
    id: 'l1',
    userId: 'u1',
    type: 'PREDICTION_PARTICIPATION',
    points: 10,
    date: '2026-06-08T17:05:00Z',
    description: 'Participación en pronóstico Croacia vs Canadá',
    referenceId: 'm8'
  },
  {
    id: 'l2',
    userId: 'u1',
    type: 'PREDICTION_EXACT',
    points: 100,
    date: '2026-06-08T19:00:00Z',
    description: 'Marcador exacto acertado en Croacia vs Canadá (4-1)',
    referenceId: 'm8'
  },
  {
    id: 'l3',
    userId: 'u1',
    type: 'PURCHASE_CODE',
    points: 300,
    date: '2026-06-09T21:00:00Z',
    description: 'Código de compra cupón "FAC-98442" redimido',
    referenceId: 'FAC-98442'
  }
];

export const INITIAL_SYSTEM_LOGS: SystemLog[] = [
  {
    id: 'log1',
    timestamp: '2026-06-11T12:00:00Z',
    type: 'INFO',
    module: 'API',
    message: 'Sincronización exitosa con la API deportiva de la FIFA.'
  },
  {
    id: 'log2',
    timestamp: '2026-06-11T12:05:00Z',
    type: 'SUCCESS',
    module: 'OTP',
    message: 'SMS OTP enviado correctamente a +57 312 987 6543'
  },
  {
    id: 'log3',
    timestamp: '2026-06-11T14:30:00Z',
    type: 'INFO',
    module: 'DATABASE',
    message: 'Base de datos Supabase conectada con estado de latencia 14ms.'
  },
  {
    id: 'log4',
    timestamp: '2026-06-11T15:00:00Z',
    type: 'SUCCESS',
    module: 'REWARDS',
    message: 'Reparto automático de puntos finalizado para el partido Bélgica vs Marruecos.'
  }
];
