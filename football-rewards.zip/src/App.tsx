/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { StateProvider, useAppState } from './context/StateContext';
import { ClientDashboard } from './components/ClientDashboard';
import { AdminPanel } from './components/AdminPanel';
import { Moon, Sun, Shield, User, Award, Flame } from 'lucide-react';

function AppContent() {
  const { activeRole, setActiveRole, currentUser, isAdmin } = useAppState();
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Sync theme with DOM body classes and local storage
  useEffect(() => {
    const savedTheme = localStorage.getItem('app-theme') as 'dark' | 'light' | null;
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  // Secure admin view access
  useEffect(() => {
    if (activeRole === 'ADMIN' && !isAdmin) {
      setActiveRole('CLIENT');
    }
  }, [activeRole, isAdmin, setActiveRole]);

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    localStorage.setItem('app-theme', nextTheme);
  };

  return (
    <div className={`min-h-screen transition-all duration-300 ${
      theme === 'dark' 
        ? 'bg-immersive-black text-[#F5F5F5]' 
        : 'bg-zinc-50 text-zinc-900'
    }`} id="app-root-container">
      
      {/* Dynamic Mode switcher Floating Bar */}
      <div className="fixed bottom-6 left-6 z-50 flex items-center gap-2">
        <button
          onClick={toggleTheme}
          id="btn-global-theme-toggle"
          title={theme === 'dark' ? 'Cambiar a Modo Claro' : 'Cambiar a Modo Oscuro'}
          className={`p-3 rounded-full shadow-glow-sm transition-all duration-300 cursor-pointer border flex items-center justify-center ${
            theme === 'dark' 
              ? 'bg-immersive-gray border-white/15 text-immersive-green hover:bg-immersive-slate hover:shadow-glow/20' 
              : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-50 shadow-zinc-200/50'
          }`}
        >
          {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
        </button>

        {/* Display Current Role badge for user assurance */}
        <span className={`text-[10px] uppercase font-bold tracking-widest font-display px-3 py-1.5 rounded-full border hidden sm:inline-block ${
          activeRole === 'ADMIN'
            ? theme === 'dark'
              ? 'bg-amber-950/40 border-amber-500/30 text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.15)]'
              : 'bg-amber-100 border-amber-200 text-amber-800'
            : theme === 'dark'
              ? 'bg-immersive-green/10 border-immersive-green/30 text-immersive-green shadow-[0_0_10px_rgba(0,255,65,0.15)]'
              : 'bg-emerald-100 border-emerald-200 text-emerald-800'
        }`}>
          {activeRole === 'ADMIN' ? 'Vista: Admin de Restaurante' : 'Vista: Cliente Móvil'}
        </span>
      </div>

      {/* Main Role Routing Center */}
      <main className="relative">
        {activeRole === 'CLIENT' ? (
          <div className="flex justify-center w-full">
            {/* The Mobile Dashboard operates inside a max-width device envelope style */}
            <div className={`w-full max-w-md ${
              theme === 'light' 
                ? 'bg-white shadow-[0_0_50px_-12px_rgba(0,0,0,0.08)] border-x border-zinc-200' 
                : 'bg-immersive-dark border-x border-white/10 shadow-glow-sm/5'
            }`}>
              {/* Force appropriate theme scopes on Client PWA components if light mode */}
              <div className={theme === 'light' ? 'light-theme-vars [&_*]:!text-zinc-900 [&_span]:!text-zinc-500 [&_strong]:!text-zinc-900 [&_h1]:!text-zinc-900 [&_h2]:!text-zinc-900 [&_h3]:!text-zinc-910 [&_h4]:!text-zinc-900 [&_input]:!text-zinc-900 [&_input]:!bg-zinc-100 [&_button:not(#btn-confirm-prediction-submit):not(#btn-auth-submit-info)]:!bg-zinc-100 [&_button:not(#btn-confirm-prediction-submit):not(#btn-auth-submit-info)]:!text-zinc-800 [&_button:not(#btn-confirm-prediction-submit):not(#btn-auth-submit-info)]:border-zinc-200 [&_.bg-zinc-900]:!bg-zinc-100 [&_.bg-zinc-950]:!bg-white [&_.border-zinc-900]:!border-zinc-200 [&_.border-zinc-801]:!border-zinc-300 [&_.bg-zinc-850]:!bg-zinc-200/80 [&_.text-zinc-100]:!text-zinc-900 [&_.text-zinc-150]:!text-zinc-900 [&_.text-zinc-350]:!text-zinc-900 [&_.text-emerald-400]:!text-emerald-600 [&_.text-amber-500]:!text-amber-600 [&_.bg-emerald-950\/40]:!bg-emerald-50 [&_.border-emerald-500\/50]:!border-emerald-200 [&_.text-zinc-250]:!test-zinc-800 [&_.bg-gradient-to-b]:!from-zinc-50 [&_.bg-zinc-900\/40]:!bg-zinc-50 [&_.bg-zinc-900\/50]:!bg-zinc-100/50 [&_.bg-zinc-950\/80]:!bg-zinc-50/90 [&_input-otp]:!text-emerald-600' : ''}>
                <ClientDashboard />
              </div>
            </div>
          </div>
        ) : (
          <div className={`w-full max-w-7xl mx-auto p-4 ${
            theme === 'light'
              ? 'light-theme-vars [&_*]:!text-zinc-900 [&_span]:!text-zinc-505 [&_strong]:!text-zinc-900 [&_h1]:!text-zinc-900 [&_h2]:!text-zinc-900 [&_h3]:!text-zinc-910 [&_h4]:!text-zinc-900 [&_input]:!text-zinc-900 [&_input]:!bg-zinc-100 [&_input]:!border-zinc-200 [&_button:not(#btn-admin-submit-code):not(#btn-admin-send-push)]:!bg-zinc-100 [&_button:not(#btn-admin-submit-code):not(#btn-admin-send-push)]:!text-zinc-800 [&_button:not(#btn-admin-submit-code):not(#btn-admin-send-push)]:border-zinc-200 [&_.bg-zinc-950]:!bg-zinc-100/50 [&_.bg-zinc-900]:!bg-zinc-200 [&_.bg-zinc-900\/40]:!bg-zinc-100/40 [&_.border-zinc-900]:!border-zinc-200 [&_.border-zinc-800]:!border-zinc-300 [&_.text-zinc-100]:!text-zinc-900 [&_.text-zinc-150]:!text-zinc-100 [&_.text-emerald-400]:!text-emerald-600 [&_.text-amber-500]:!text-amber-600 [&_.bg-zinc-905]:!bg-zinc-200 [&_.bg-zinc-955]:!bg-zinc-100/10' : ''
          }`}>
            <AdminPanel />
          </div>
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <StateProvider>
      <AppContent />
    </StateProvider>
  );
}
