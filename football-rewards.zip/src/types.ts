export interface User {
  id: string;
  name: string;
  phone: string;
  registerDate: string;
  points: number;
  pointsFromPredictions: number;
  pointsFromPurchases: number;
  active: boolean; // false if blocked
  streak: number; // current consecutive hits
  maxStreak: number;
  hitsCount: number; // number of correct outcomes or exact matches
  missesCount: number; // number of incorrect outcomes
  predictionsCount: number;
}

export interface MatchStats {
  possessionHome: number;
  possessionAway: number;
  shotsHome: number;
  shotsAway: number;
  foulsHome: number;
  foulsAway: number;
}

export interface Match {
  id: string;
  homeTeam: string;
  homeFlag: string; // Emoji
  awayTeam: string;
  awayFlag: string; // Emoji
  date: string; // ISO string
  status: 'PENDING' | 'LIVE' | 'FINISHED';
  homeScore?: number;
  awayScore?: number;
  stage: string; // e.g., "Fase de Grupos", "Octavos de Final", "Semifinal", "Final"
  stats?: MatchStats;
}

export interface Prediction {
  id: string;
  userId: string;
  matchId: string;
  predictedWinner: 'LOCAL' | 'DRAW' | 'AWAY';
  predictedHomeScore: number;
  predictedAwayScore: number;
  status: 'PENDING' | 'CORRECT_EXACT' | 'CORRECT_OUTCOME' | 'INCORRECT'; // CORRECT_EXACT (+100 pts), CORRECT_OUTCOME (+50 pts)
  pointsAwarded: number;
}

export interface PromoCode {
  id: string;
  code: string;
  purchaseValue: number;
  points: number;
  expirationDate: string; // YYYY-MM-DD
  maxUses: number;
  usedCount: number;
  active: boolean;
  claims: Array<{
    userId: string;
    userName: string;
    date: string;
  }>;
}

export interface PointsLog {
  id: string;
  userId: string;
  type: 'PREDICTION_PARTICIPATION' | 'PREDICTION_OUTCOME' | 'PREDICTION_EXACT' | 'PREDICTION_BONUS_3' | 'PREDICTION_BONUS_5' | 'PURCHASE_CODE';
  points: number;
  date: string;
  description: string;
  referenceId?: string; // matchId or script/code
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: 'Award' | 'Sparkles' | 'TrendingUp' | 'Crown' | 'Zap' | 'Flame' | 'UserCheck' | 'CheckCircle';
  category: 'first_hit' | 'streak_5' | 'top_10' | 'top_3' | 'leader' | 'active_user';
}

export interface SystemConfig {
  pointsPerAmountSpent: number; // e.g. 1 point
  amountMultiplierStep: number;  // e.g. per 1000 COP (default is 1000)
  discountFirst: number;     // 50%
  discountSecond: number;    // 40%
  discountThird: number;     // 30%
  discountOthers4to10: number; // 15%
  positionsRewarded: number; // 10
}

export interface PushNotification {
  id: string;
  title: string;
  body: string;
  date: string;
  type: 'MATCH' | 'POINTS' | 'RANKING' | 'SYSTEM';
  read: boolean;
  segment?: 'all' | 'high_part' | 'top_10';
}

export interface SystemLog {
  id: string;
  timestamp: string;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR';
  module: 'AUTH' | 'DATABASE' | 'OTP' | 'API' | 'ADMIN' | 'REWARDS';
  message: string;
}
