import React, { useState, useMemo } from 'react';
import { PointsLog, User } from '../types';
import { 
  Search, Filter, ArrowUpDown, Gift, Award, Target, Flame, 
  Sparkles, TrendingUp, Calendar, Zap, AlertCircle 
} from 'lucide-react';

interface PointsHistoryProps {
  userLogs: PointsLog[];
  currentUser: User;
}

type FilterType = 'ALL' | 'PREDICTIONS' | 'CODES' | 'BONUSES';
type SortType = 'DATE_DESC' | 'DATE_ASC' | 'POINTS_DESC' | 'POINTS_ASC';

export const PointsHistory: React.FC<PointsHistoryProps> = ({ userLogs, currentUser }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<FilterType>('ALL');
  const [sortBy, setSortBy] = useState<SortType>('DATE_DESC');

  // Compute stats based on the logs
  const stats = useMemo(() => {
    let codePoints = 0;
    let predictionPoints = 0;
    let bonusPoints = 0;

    userLogs.forEach(log => {
      if (log.type === 'PURCHASE_CODE') {
        codePoints += log.points;
      } else if (
        log.type === 'PREDICTION_BONUS_3' || 
        log.type === 'PREDICTION_BONUS_5'
      ) {
        bonusPoints += log.points;
      } else {
        predictionPoints += log.points;
      }
    });

    const total = codePoints + predictionPoints + bonusPoints;

    return {
      total,
      codePoints,
      predictionPoints,
      bonusPoints,
      codePercent: total > 0 ? Math.round((codePoints / total) * 100) : 0,
      predictionPercent: total > 0 ? Math.round((predictionPoints / total) * 100) : 0,
      bonusPercent: total > 0 ? Math.round((bonusPoints / total) * 100) : 0,
    };
  }, [userLogs]);

  // Process, filter, and sort logs
  const processedLogs = useMemo(() => {
    let result = [...userLogs];

    // 1. Search term filter
    if (searchTerm.trim() !== '') {
      const term = searchTerm.toLowerCase();
      result = result.filter(log => 
        log.description.toLowerCase().includes(term) ||
        log.type.toLowerCase().includes(term) ||
        log.points.toString().includes(term)
      );
    }

    // 2. Type category filter
    if (filterType !== 'ALL') {
      result = result.filter(log => {
        switch (filterType) {
          case 'PREDICTIONS':
            return [
              'PREDICTION_PARTICIPATION', 
              'PREDICTION_OUTCOME', 
              'PREDICTION_EXACT'
            ].includes(log.type);
          case 'CODES':
            return log.type === 'PURCHASE_CODE';
          case 'BONUSES':
            return [
              'PREDICTION_BONUS_3', 
              'PREDICTION_BONUS_5'
            ].includes(log.type);
          default:
            return true;
        }
      });
    }

    // 3. Sorting
    result.sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      
      switch (sortBy) {
        case 'DATE_DESC':
          return dateB - dateA;
        case 'DATE_ASC':
          return dateA - dateB;
        case 'POINTS_DESC':
          return b.points - a.points;
        case 'POINTS_ASC':
          return a.points - b.points;
        default:
          return dateB - dateA;
      }
    });

    return result;
  }, [userLogs, searchTerm, filterType, sortBy]);

  // Map transaction type to localized badges, styles, and icons
  const getLogTypeMetadata = (type: PointsLog['type']) => {
    switch (type) {
      case 'PURCHASE_CODE':
        return {
          icon: Gift,
          bgClass: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
          badgeText: 'Factura / Código',
          accentColor: 'text-emerald-400',
        };
      case 'PREDICTION_EXACT':
        return {
          icon: Target,
          bgClass: 'bg-purple-500/10 border-purple-500/30 text-purple-400',
          badgeText: 'Marcador Exacto',
          accentColor: 'text-purple-400',
        };
      case 'PREDICTION_OUTCOME':
        return {
          icon: Award,
          bgClass: 'bg-sky-500/10 border-sky-500/30 text-sky-400',
          badgeText: 'Ganador Partido',
          accentColor: 'text-sky-400',
        };
      case 'PREDICTION_PARTICIPATION':
        return {
          icon: Calendar,
          bgClass: 'bg-zinc-500/10 border-zinc-500/30 text-zinc-400',
          badgeText: 'Participación',
          accentColor: 'text-zinc-400',
        };
      case 'PREDICTION_BONUS_3':
        return {
          icon: Flame,
          bgClass: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
          badgeText: 'Bono Racha x3',
          accentColor: 'text-amber-400',
        };
      case 'PREDICTION_BONUS_5':
        return {
          icon: Zap,
          bgClass: 'bg-red-500/10 border-red-500/30 text-red-500',
          badgeText: 'Super Bono x5',
          accentColor: 'text-red-400',
        };
      default:
        return {
          icon: Sparkles,
          bgClass: 'bg-immersive-green/10 border-immersive-green/20 text-[#00FF41]',
          badgeText: 'Sistema',
          accentColor: 'text-[#00FF41]',
        };
    }
  };

  return (
    <div className="space-y-4 font-sans" id="points-movement-history-component">
      {/* Decorative Title & Icon banner */}
      <div className="flex items-center justify-between border-b border-white/5 pb-2">
        <h3 className="text-xs font-black text-immersive-green uppercase tracking-widest font-display flex items-center gap-1.5">
          <TrendingUp size={14} className="text-immersive-green" /> Historial de Movimientos
        </h3>
        <span className="text-[9px] text-white/40 font-mono tracking-wider">{userLogs.length} transacciones</span>
      </div>

      {/* Modern Loyalty Metrics Visualizer Panel */}
      <div className="bg-immersive-slate p-4 rounded-2xl border border-white/5 space-y-3.5 shadow-inner">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-[8px] text-white/40 uppercase tracking-widest font-display block">Total Histórico</span>
            <span className="text-xl font-black font-mono text-immersive-green tracking-tighter block">
              +{stats.total.toLocaleString()} pts
            </span>
          </div>
          <div className="text-right space-y-0.5">
            <span className="text-[8px] text-white/40 uppercase tracking-widest font-display block">Balance en Perfil</span>
            <span className="text-sm font-black font-mono text-white tracking-tighter block">
              {currentUser.points.toLocaleString()} pts
            </span>
          </div>
        </div>

        {/* Visual Multi-Segment Bar */}
        <div className="space-y-1">
          <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden flex">
            <div 
              style={{ width: `${stats.codePercent}%` }} 
              className="bg-emerald-500 h-full transition-all duration-500" 
              title={`Facturas: ${stats.codePoints} pts`}
            />
            <div 
              style={{ width: `${stats.predictionPercent}%` }} 
              className="bg-sky-500 h-full transition-all duration-500" 
              title={`Pronósticos: ${stats.predictionPoints} pts`}
            />
            <div 
              style={{ width: `${stats.bonusPercent}%` }} 
              className="bg-amber-500 h-full transition-all duration-500" 
              title={`Bonos: ${stats.bonusPoints} pts`}
            />
          </div>
          
          {/* Segment Legends Row */}
          <div className="flex items-center justify-between gap-1 text-[9px] font-medium pt-1 text-white/50">
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
              <span>Consumos: <strong className="text-white font-mono font-bold">{stats.codePercent}%</strong></span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-500 shrink-0"></span>
              <span>Pronósticos: <strong className="text-white font-mono font-bold">{stats.predictionPercent}%</strong></span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
              <span>Rachas/Bonos: <strong className="text-white font-mono font-bold">{stats.bonusPercent}%</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Controls Panel */}
      <div className="bg-immersive-dark/50 border border-white/5 rounded-2xl p-3.5 space-y-3">
        {/* Search bar inside history */}
        <div className="relative">
          <input
            type="text"
            id="history-search-input"
            placeholder="Buscar por descripción..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-9 pr-4 text-xs text-white placeholder:text-white/20 focus:outline-none focus:border-immersive-green"
          />
          <Search size={13} className="absolute left-3 top-2.5 text-white/30" />
          {searchTerm && (
            <button 
              onClick={() => setSearchTerm('')} 
              className="absolute right-3 top-2 text-[10px] text-white/40 hover:text-white"
            >
              [borrar]
            </button>
          )}
        </div>

        {/* Filters and Sort Selection Box */}
        <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center justify-between">
          {/* Categories select pills */}
          <div className="flex flex-wrap gap-1" id="history-filter-pills">
            {(['ALL', 'PREDICTIONS', 'CODES', 'BONUSES'] as FilterType[]).map(type => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                  filterType === type
                    ? 'bg-immersive-green text-black font-black'
                    : 'bg-white/5 border border-white/5 text-white/50 hover:text-white hover:bg-white/10'
                }`}
              >
                {type === 'ALL' ? 'Todos' : type === 'PREDICTIONS' ? 'Pronósticos' : type === 'CODES' ? 'Códigos' : 'Bonos'}
              </button>
            ))}
          </div>

          {/* Sort Selector Dropdown */}
          <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-auto">
            <span className="text-[9px] text-white/30 font-bold uppercase tracking-wider flex items-center gap-1">
              <ArrowUpDown size={10} /> Ordenar:
            </span>
            <select
              id="history-sort-dropdown"
              value={sortBy}
              onChange={e => setSortBy(e.target.value as SortType)}
              className="bg-immersive-slate border border-white/10 rounded-lg py-1 px-2 text-[9px] font-bold text-white/80 focus:outline-none focus:border-immersive-green cursor-pointer"
            >
              <option value="DATE_DESC">Recientes primero</option>
              <option value="DATE_ASC">Antiguos primero</option>
              <option value="POINTS_DESC">Mayor Puntaje</option>
              <option value="POINTS_ASC">Menor Puntaje</option>
            </select>
          </div>
        </div>
      </div>

      {/* Transactional List Cards View */}
      <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 select-none custom-scrollbar" id="history-logs-container">
        {processedLogs.length === 0 ? (
          <div className="text-center py-8 bg-white/5 rounded-2xl border border-white/5 space-y-1.5">
            <AlertCircle size={20} className="text-white/20 mx-auto" />
            <p className="text-xs text-white/40 italic">No se encontraron movimientos con los filtros aplicados.</p>
          </div>
        ) : (
          processedLogs.map(log => {
            const meta = getLogTypeMetadata(log.type);
            const IconComp = meta.icon;

            return (
              <div 
                key={log.id} 
                className="bg-immersive-slate/40 hover:bg-immersive-slate/60 border border-white/5 p-3 rounded-xl flex items-center justify-between text-xs transition-colors group"
                id={`points-log-item-${log.id}`}
              >
                <div className="flex items-center gap-3">
                  {/* Type themed circular icon indicator */}
                  <div className={`w-8 h-8 rounded-xl border flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 duration-200 ${meta.bgClass}`}>
                    <IconComp size={14} />
                  </div>

                  <div className="space-y-0.5">
                    {/* Category Label badge & Date stamp */}
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[8px] font-extrabold uppercase tracking-widest px-1.5 py-0.5 rounded ${meta.bgClass}`}>
                        {meta.badgeText}
                      </span>
                      <span className="text-[8.5px] text-white/30 font-mono">
                        {new Date(log.date).toLocaleDateString([], { month: 'short', day: 'numeric' })} • {new Date(log.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    {/* Action Title/Description */}
                    <span className="font-extrabold text-white block uppercase tracking-tight leading-snug group-hover:text-immersive-green transition-colors">
                      {log.description}
                    </span>
                  </div>
                </div>

                {/* Score Award Value marker */}
                <div className="text-right shrink-0 ml-3">
                  <span className={`font-mono font-black text-xs bg-white/5 px-2 py-1 rounded-xl border border-white/5 inline-block ${meta.accentColor} shadow-glow-sm/10`}>
                    +{log.points} pts
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
