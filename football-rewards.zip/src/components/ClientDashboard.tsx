import React, { useState } from 'react';
import { useAppState } from '../context/StateContext';
import { Match, PointsLog } from '../types';
import { PointsHistory } from './PointsHistory';
import {
  Award, Bell, CheckCircle, Smartphone, User, Gift, ChevronRight, Check,
  Trophy, TrendingUp, Flame, Star, ShieldAlert, Sparkles, BookOpen, AlertCircle, Phone, UserCheck, FlameKindling, Info
} from 'lucide-react';

export const ClientDashboard: React.FC = () => {
  const {
    currentUser, sendOtp, verifyOtp, logout, matches, predictions, placePrediction,
    claimPromoCode, pointsLogs, notifications, getLeaderboardStats, getCalculatedBadges, systemConfig,
    syncRealMatchesFromESPN, isAdmin, setActiveRole
  } = useAppState();

  const [activeClientTab, setActiveClientTab] = useState<'matches' | 'ranking' | 'claim' | 'progress'>('matches');
  
  // ESPN API Sync stats
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  // Auth Form State
  const [authName, setAuthName] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authStep, setAuthStep] = useState<'info' | 'otp'>('info');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [authError, setAuthError] = useState('');

  // Claim Code Input
  const [claimInput, setClaimInput] = useState('');
  const [claimErr, setClaimErr] = useState('');
  const [claimSucc, setClaimSucc] = useState('');

  // Selected Prediction Match state
  const [predictingMatch, setPredictingMatch] = useState<Match | null>(null);
  const [pickWinner, setPickWinner] = useState<'LOCAL' | 'DRAW' | 'AWAY'>('LOCAL');
  const [pickHomeScore, setPickHomeScore] = useState(1);
  const [pickAwayScore, setPickAwayScore] = useState(1);

  // Notification center sliding menu
  const [showNotifications, setShowNotifications] = useState(false);

  // Computed values
  const { top10, userRank, pointsToTop10, pointsToLeader } = getLeaderboardStats();

  // Handle Send OTP Form
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    if (!authName.trim()) {
      setAuthError('Escribe tu nombre completo.');
      return;
    }
    if (!authPhone.trim()) {
      setAuthError('Escribe tu número de teléfono móvil.');
      return;
    }

    const { success, code } = sendOtp(authName, authPhone);
    if (success) {
      setGeneratedOtp(code);
      setAuthStep('otp');
    } else {
      setAuthError('No se pudo simular el SMS OTP.');
    }
  };

  // Handle Verify OTP
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    const { success, error } = verifyOtp(authPhone, authName, enteredOtp);
    if (success) {
      // successfully logged in!
      setAuthName('');
      setAuthPhone('');
      setAuthStep('info');
      setEnteredOtp('');
    } else {
      setAuthError(error || 'Código incorrecto.');
    }
  };

  const handlePredictSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!predictingMatch) return;

    const { success, message } = placePrediction(
      predictingMatch.id,
      pickWinner,
      pickHomeScore,
      pickAwayScore
    );

    if (success) {
      setPredictingMatch(null);
    } else {
      alert(message);
    }
  };

  const handleClaim = (e: React.FormEvent) => {
    e.preventDefault();
    setClaimErr('');
    setClaimSucc('');

    if (!claimInput.trim()) {
      setClaimErr('Escribe un código.');
      return;
    }

    const { success, message, pointsAwarded } = claimPromoCode(claimInput);
    if (success) {
      setClaimSucc(message);
      setClaimInput('');
    } else {
      setClaimErr(message);
    }
  };

  // User details stats (if logged in)
  const userBadges = currentUser ? getCalculatedBadges(currentUser.id) : [];
  const userLogs = currentUser ? pointsLogs.filter(l => l.userId === currentUser.id) : [];

  // Calculate effectiveness %
  const effectiveness = currentUser && currentUser.predictionsCount > 0
    ? Math.round((currentUser.hitsCount / currentUser.predictionsCount) * 100)
    : 0;

  // View: NOT LOGGED IN AUTH SCREEN
  if (!currentUser) {
    return (
      <div className="flex items-center justify-center min-h-[80vh] px-4 font-sans" id="auth-screen-pwa">
        <div className="w-full max-w-md bg-immersive-dark border border-white/10 rounded-3xl p-6 sm:p-8 shadow-glow-sm relative overflow-hidden">
          {/* Accent decoration representing stadium lighting */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-immersive-green via-white/50 to-immersive-green"></div>

          <div className="text-center mb-6">
            <span className="text-[10px] uppercase font-black bg-immersive-green/10 text-immersive-green px-3 py-1 rounded-full border border-immersive-green/30 tracking-widest inline-block">
              Club de Fidelización
            </span>
            <h2 className="text-2xl font-black font-display text-white mt-3 tracking-tighter uppercase">FOOTBALL <span className="text-immersive-green">REWARDS</span></h2>
            <p className="text-xs text-white/50 mt-1">Gana premios en el restaurante con tus conocimientos deportivos.</p>
          </div>

          {authStep === 'info' ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] text-white/40 font-bold uppercase tracking-wider block font-display">Nombre Completo</label>
                <input
                  type="text"
                  required
                  id="auth-input-name"
                  placeholder="Ej: James Rodríguez"
                  value={authName}
                  onChange={e => setAuthName(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white placeholder:text-white/20 focus:outline-none focus:border-immersive-green focus:ring-1 focus:ring-immersive-green/20"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-white/40 font-bold uppercase tracking-wider block font-display">Número de Teléfono</label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    id="auth-input-phone"
                    placeholder="Ej: 300 123 4567"
                    value={authPhone}
                    onChange={e => setAuthPhone(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder:text-white/20 focus:outline-none focus:border-immersive-green focus:ring-1 focus:ring-immersive-green/20"
                  />
                  <Phone size={14} className="absolute left-4 top-3.5 text-white/30" />
                </div>
                <span className="text-[9.5px] text-white/30 italic block mt-1">* Se enviará un SMS OTP de validación para registro automático</span>
              </div>

              <button
                type="submit"
                id="btn-auth-submit-info"
                className="w-full bg-immersive-green hover:bg-immersive-green/90 text-black font-black py-3 rounded-2xl text-xs tracking-wider transition-all duration-300 font-display flex items-center justify-center gap-1.5 cursor-pointer shadow-glow hover:scale-[1.01]"
              >
                Recibir Código OTP SMS
              </button>

              {authError && <div className="p-3 bg-red-950/40 border border-red-900/30 text-red-400 rounded-xl text-center text-xs">{authError}</div>}
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-5">
              <div className="bg-white/5 p-3.5 rounded-2xl border border-white/5 text-center space-y-2">
                <span className="text-[10px] text-white/40 font-display uppercase tracking-widest block font-bold">Instrucciones de Verificación</span>
                <p className="text-xs text-white/80">Hemos enviado un código SMS temporal a tu teléfono <strong className="text-white">{authPhone}</strong></p>
                
                {/* Instant SMS simulator box */}
                <div className="pt-2 border-t border-white/5 mt-1">
                  <span className="text-[9px] bg-immersive-green/10 text-immersive-green font-mono font-bold px-2.5 py-1 rounded block border border-immersive-green/20">
                     ENTRANTE SMS OTP SIMULADOR: <strong className="text-white text-xs font-black tracking-widest ml-1">{generatedOtp}</strong>
                  </span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-white/45 font-bold uppercase tracking-wider block font-display text-center">Ingresar OTP de 4 dígitos</label>
                <input
                  type="text"
                  required
                  maxLength={4}
                  id="auth-input-otp"
                  placeholder="****"
                  value={enteredOtp}
                  onChange={e => setEnteredOtp(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-center text-lg font-mono font-bold tracking-widest text-[#00FF41] placeholder:text-white/20 focus:outline-none focus:border-immersive-green"
                />
              </div>

              <div className="flex gap-2.5">
                <button
                  type="button"
                  onClick={() => setAuthStep('info')}
                  className="w-1/3 bg-white/5 hover:bg-white/10 border border-white/5 text-white/60 py-3 rounded-2xl text-[11px] transition-colors font-display font-medium cursor-pointer"
                >
                  Regresar
                </button>
                <button
                  type="submit"
                  id="btn-auth-verify-otp"
                  className="w-2/3 bg-immersive-green hover:bg-immersive-green/90 text-black font-black py-3 rounded-2xl text-xs tracking-wider transition-all duration-300 font-display cursor-pointer flex items-center justify-center gap-1 shadow-glow"
                >
                  Verificar y Acceder
                </button>
              </div>

              {authError && <div className="p-3 bg-red-950/40 border border-red-900/40 text-red-400 rounded-xl text-center text-xs">{authError}</div>}
            </form>
          )}
        </div>
      </div>
    );
  }

  // VIEW: AUTHENTICATED PWA DASHBOARD SYSTEM
  return (
    <div className="max-w-md mx-auto bg-immersive-black text-white min-h-screen border-x border-white/10 relative shadow-2xl pb-24 font-sans animate-in fade-in duration-300" id="pwa-dashboard">
      {/* Mobile-Styled App Header Bar */}
      <header className="bg-immersive-dark border-b border-white/10 sticky top-0 z-40 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Logo emblem */}
          <div className="w-8 h-8 rounded bg-immersive-green flex items-center justify-center text-black font-black text-xs tracking-tighter shadow-glow">
            <svg className="w-4 h-4 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
          </div>
          <div>
            <h1 className="text-xs font-black tracking-tighter uppercase font-display text-white">
              FOOTBALL <span className="text-immersive-green">REWARDS</span>
            </h1>
            <p className="text-[9px] text-white/40 uppercase tracking-widest font-mono font-bold">Mundial Club PWA</p>
          </div>
        </div>

        {/* Bell Alerts & Logout Header Actions */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 hover:bg-white/5 rounded-xl transition-colors relative cursor-pointer"
            id="btn-bell-notifications"
          >
            <Bell size={16} className="text-white/70 hover:text-white" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-immersive-green shadow-[0_0_8px_#00FF41]"></span>
          </button>
          
          <button
            onClick={logout}
            className="text-[9px] uppercase tracking-widest font-black text-white/50 hover:text-red-400 bg-white/5 px-2.5 py-1 rounded border border-white/5 transition-colors cursor-pointer"
          >
            Salir
          </button>
        </div>
      </header>

      {/* Slide-out simulated notifications panel */}
      {showNotifications && (
        <div className="absolute top-12 left-0 right-0 max-w-md mx-auto bg-immersive-dark border-b border-white/10 z-50 p-4 shadow-glow animate-in slide-in-from-top duration-300">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-black text-immersive-green font-display uppercase tracking-widest flex items-center gap-1.5">
              <Bell size={13} className="text-immersive-green animate-bounce" /> NOTIFICACIONES RECIBIDAS
            </span>
            <button
              onClick={() => setShowNotifications(false)}
              className="text-[10px] text-white/50 hover:text-white uppercase font-bold"
            >
              [Cerrar]
            </button>
          </div>

          <div className="space-y-2 max-h-64 overflow-y-auto pr-1 custom-scrollbar">
            {notifications.map(notif => (
              <div key={notif.id} className="bg-immersive-slate rounded-xl p-3 border border-white/5 shadow-inner">
                <span className="text-[9px] text-immersive-green font-mono font-bold block mb-0.5">{notif.type} • {new Date(notif.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                <h4 className="text-xs font-black text-white uppercase tracking-tight leading-tight">{notif.title}</h4>
                <p className="text-[11px] text-white/60 mt-1 leading-relaxed">{notif.body}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* User Profile Quick Banner widget */}
      <section className="p-4 bg-gradient-to-b from-white/5 to-transparent border-b border-white/10 flex items-center justify-between">
        <div className="space-y-1">
          <span className="text-[9px] font-black text-white/40 uppercase tracking-widest font-display block">Socio Activo</span>
          <h2 className="text-base font-black font-display text-white uppercase tracking-tight truncate max-w-[200px]">{currentUser.name}</h2>
          <span className="text-[9.5px] font-mono text-white/50 block">📱 {currentUser.phone}</span>
        </div>

        {/* User Points Badge Card */}
        <div className="bg-immersive-slate px-4 py-2 rounded-2xl border border-white/10 flex flex-col items-end shadow-inner">
          <span className="text-[8px] text-white/50 uppercase tracking-widest font-black font-display block">Puntos Acumulados</span>
          <span className="text-lg font-mono text-immersive-green font-black tracking-tighter block">
            {currentUser.points.toLocaleString()}
          </span>
          <span className="text-[9px] bg-white/5 border border-white/5 px-1.5 py-0.5 rounded text-[#00FF41] font-black font-mono">Rank #{userRank}</span>
        </div>
      </section>

      {/* Admin Quick Switch Access Portal */}
      {isAdmin && (
        <section className="px-4 py-3 bg-amber-500/10 border-b border-amber-500/20 flex items-center justify-between" id="section-admin-entry-banner">
          <div className="flex items-center gap-2">
            <ShieldAlert size={16} className="text-amber-400" />
            <div>
              <span className="text-[10px] font-bold text-amber-400 font-display uppercase block">Perfil de Administrador</span>
              <span className="text-[9px] text-white/60">Gestiona partidos, puntajes de socios y códigos.</span>
            </div>
          </div>
          <button
            id="btn-switch-to-admin-panel"
            onClick={() => setActiveRole('ADMIN')}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-black text-[9px] font-black font-display uppercase tracking-wider rounded-lg shadow transition-all cursor-pointer"
          >
            Panel Admin <ChevronRight size={12} />
          </button>
        </section>
      )}

      {/* PWA Tabs Menu Center */}
      <div className="p-4">
        <nav className="flex justify-between bg-immersive-slate p-1 rounded-xl border border-white/10 mb-6 shadow-inner">
          <button
            onClick={() => setActiveClientTab('matches')}
            className={`w-1/4 py-2.5 rounded-lg text-[9px] font-black font-display uppercase tracking-wider transition-all cursor-pointer text-center ${
              activeClientTab === 'matches'
                ? 'bg-immersive-green text-black shadow-glow font-black scale-[1.02]'
                : 'text-white/55 hover:text-white hover:bg-white/5'
            }`}
          >
            Mundial
          </button>
          <button
            onClick={() => setActiveClientTab('ranking')}
            className={`w-1/4 py-2.5 rounded-lg text-[9px] font-black font-display uppercase tracking-wider transition-all cursor-pointer text-center ${
              activeClientTab === 'ranking'
                ? 'bg-immersive-green text-black shadow-glow font-black scale-[1.02]'
                : 'text-white/55 hover:text-white hover:bg-white/5'
            }`}
          >
            Ranking
          </button>
          <button
            onClick={() => setActiveClientTab('claim')}
            className={`w-1/4 py-2.5 rounded-lg text-[9px] font-black font-display uppercase tracking-wider transition-all cursor-pointer text-center ${
              activeClientTab === 'claim'
                ? 'bg-immersive-green text-black shadow-glow font-black scale-[1.02]'
                : 'text-white/55 hover:text-white hover:bg-white/5'
            }`}
          >
            Canjear
          </button>
          <button
            onClick={() => setActiveClientTab('progress')}
            className={`w-1/4 py-2.5 rounded-lg text-[9px] font-black font-display uppercase tracking-wider transition-all cursor-pointer text-center ${
              activeClientTab === 'progress'
                ? 'bg-immersive-green text-black shadow-glow font-black scale-[1.02]'
                : 'text-white/55 hover:text-white hover:bg-white/5'
            }`}
          >
            Progreso
          </button>
        </nav>

        {/* TAB 1: CALENDAR & PREDICTIONS MAP */}
        {activeClientTab === 'matches' && (
          <div id="tab-client-matches" className="space-y-4">
            <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2.5 mb-3">
              <h3 className="text-[10px] font-black text-immersive-green uppercase tracking-widest font-display flex flex-col sm:flex-row sm:items-center gap-1">
                <span>Calendario de Partidos</span>
                <span className="text-[8px] text-white/40 font-mono normal-case sm:border-l sm:border-white/10 sm:pl-1.5 sm:ml-0.5">Mundial 2026 (ESPN API)</span>
              </h3>
              <button
                disabled={isSyncing}
                onClick={async () => {
                  setIsSyncing(true);
                  setSyncStatus('Sincronizando...');
                  const res = await syncRealMatchesFromESPN();
                  setSyncStatus(res.message);
                  setIsSyncing(false);
                  setTimeout(() => setSyncStatus(null), 5000);
                }}
                className="bg-white/5 hover:bg-white/10 text-white/80 border border-white/10 active:scale-95 text-[9px] font-black uppercase tracking-wider py-1 px-3 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
              >
                <svg className={`w-3 h-3 ${isSyncing ? 'animate-spin text-immersive-green' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="12" height="12">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.21 16H18m0 0l3 3m-3-3l3-3" />
                </svg>
                {isSyncing ? 'Sincronizando' : 'Sincronizar ESPN'}
              </button>
            </div>

            {syncStatus && (
              <div className="text-[10px] font-mono text-immersive-green bg-immersive-green/5 border border-immersive-green/20 px-3 py-2 rounded-xl mb-3 animate-in fade-in slide-in-from-top-1 duration-200">
                ⚡ {syncStatus}
              </div>
            )}

            <div className="space-y-3">
              {matches.map(m => {
                // Find user prediction for this game if exists
                const userPred = predictions.find(p => p.userId === currentUser.id && p.matchId === m.id);

                return (
                  <div key={m.id} className="bg-immersive-dark border border-white/10 rounded-2xl p-4 space-y-3 transition-colors hover:border-immersive-green/20">
                    {/* Top Row detail Stage / live status */}
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-white/40 uppercase tracking-wider font-mono text-[9px]">{m.stage}</span>
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black tracking-widest ${
                        m.status === 'LIVE' ? 'bg-red-500/10 text-red-500 border border-red-500/25 animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.25)]' :
                        m.status === 'FINISHED' ? 'bg-white/5 text-white/40 border border-white/5' :
                        'bg-immersive-green/10 text-immersive-green border border-immersive-green/25'
                      }`}>
                        {m.status === 'LIVE' ? '🔴 EN VIVO' : m.status === 'FINISHED' ? 'CONCLUIDO' : 'ABIERTO'}
                      </span>
                    </div>

                    {/* Flags / Names and Score */}
                    <div className="flex items-center justify-between py-1">
                      <div className="flex items-center gap-2 w-5/12">
                        <span className="text-xl shrink-0">{m.homeFlag}</span>
                        <span className="text-xs font-black text-white truncate font-display uppercase tracking-tight">{m.homeTeam}</span>
                      </div>

                      <div className="w-2/12 text-center">
                        {m.status !== 'PENDING' ? (
                          <span className="font-extrabold text-sm font-mono tracking-wider bg-white/5 px-2 py-1 rounded border border-white/10 text-immersive-green">
                            {m.homeScore}-{m.awayScore}
                          </span>
                        ) : (
                          <span className="text-xs text-white/30 font-mono">VS</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 justify-end w-5/12 text-right">
                        <span className="text-xs font-black text-white truncate font-display uppercase tracking-tight">{m.awayTeam}</span>
                        <span className="text-xl shrink-0">{m.awayFlag}</span>
                      </div>
                    </div>

                    {/* Prediction Outcome Placement card */}
                    <div className="border-t border-white/5 pt-2 flex items-center justify-between">
                      {userPred ? (
                        <div className="w-full flex items-center justify-between text-[11px] bg-white/5 px-3 py-2 rounded-xl border border-white/5">
                          <div>
                            <span className="text-white/50">Tu pronóstico: </span>
                            <strong className="text-immersive-green font-bold whitespace-nowrap">
                              {userPred.predictedWinner === 'LOCAL' ? m.homeTeam : userPred.predictedWinner === 'AWAY' ? m.awayTeam : 'Empate'} ({userPred.predictedHomeScore}-{userPred.predictedAwayScore})
                            </strong>
                          </div>

                          {m.status === 'FINISHED' ? (
                            <span className={`font-black uppercase tracking-wider text-[8px] px-2 py-0.5 rounded shrink-0 ${
                              userPred.status === 'CORRECT_EXACT' ? 'bg-immersive-green/10 text-immersive-green border border-immersive-green/30 px-2' :
                              userPred.status === 'CORRECT_OUTCOME' ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30 px-2' :
                              'bg-white/5 text-white/40'
                            }`}>
                              {userPred.status === 'CORRECT_EXACT' ? '+100 exacto' :
                               userPred.status === 'CORRECT_OUTCOME' ? '+50 resultado' :
                               'fallido'}
                            </span>
                          ) : (
                            <button
                              disabled={m.status !== 'PENDING'}
                              onClick={() => {
                                setPredictingMatch(m);
                                setPickWinner(userPred.predictedWinner);
                                setPickHomeScore(userPred.predictedHomeScore);
                                setPickAwayScore(userPred.predictedAwayScore);
                              }}
                              className="text-immersive-green hover:underline font-black text-[10px] cursor-pointer"
                            >
                              Modificar
                            </button>
                          )}
                        </div>
                      ) : (
                        <div className="w-full flex justify-between items-center w-full">
                          <span className="text-[10px] text-white/40 italic">No has ingresado pronóstico para este partido.</span>
                          {m.status === 'PENDING' ? (
                            <button
                              onClick={() => {
                                setPredictingMatch(m);
                                setPickWinner('LOCAL');
                                setPickHomeScore(1);
                                setPickAwayScore(1);
                              }}
                              className="text-[10px] bg-immersive-green hover:bg-immersive-green/90 text-black font-black uppercase px-3 py-1.5 rounded transition-transform hover:scale-105 active:scale-95 duration-105 cursor-pointer font-display shadow-glow"
                            >
                              Pronosticar
                            </button>
                          ) : (
                            <span className="text-[10px] text-zinc-650 font-mono font-bold tracking-widest">CERRADO</span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: RANKING GENERAL & CONTEXT */}
        {activeClientTab === 'ranking' && (
          <div id="tab-client-ranking" className="space-y-4">
            {/* Gamification summary comparison widget */}
            <div className="bg-immersive-slate p-4 rounded-2xl border border-white/5 space-y-2.5">
              <span className="text-[8px] bg-amber-500/15 text-amber-400 border border-amber-500/25 px-2.5 py-1 rounded font-black uppercase tracking-widest font-display inline-block">
                Estado del Torneo General
              </span>
              <p className="text-xs text-white/60 leading-relaxed font-sans">
                ¡Los 10 mejores del ranking acumulativo final ganarán grandes descuentos en el restaurante deportivos al final del Mundial!
              </p>

              {/* Progress dynamic math calculation display */}
              <div className="grid grid-cols-2 gap-4 border-t border-white/5 pt-3">
                <div className="space-y-0.5">
                  <span className="text-[9px] text-white/40 uppercase tracking-wider block font-mono">DISTANCIA AL TOP 10</span>
                  <span className="text-xs font-black text-amber-500 font-mono">
                    {pointsToTop10 > 0 ? `Faltan +${pointsToTop10} pts` : '¡Ya estás en el Top 10! 🏆'}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[9px] text-white/40 uppercase tracking-wider block font-mono">DISTANCIA AL LÍDER</span>
                  <span className="text-xs font-black text-immersive-green font-mono">
                    {pointsToLeader > 0 ? `Faltan +${pointsToLeader} pts` : '¡Eres el líder actual! 👑'}
                  </span>
                </div>
              </div>
            </div>

            {/* List top-10 leaderboard */}
            <div className="space-y-2">
              <span className="text-[9px] text-white/40 font-black uppercase tracking-widest font-display block mb-1">
                Tabla de Posiciones Oficial LÍDERES
              </span>

              <div className="space-y-1.5 max-h-[500px] overflow-y-auto pr-1">
                {top10.map((usr, index) => {
                  const position = index + 1;
                  const isCur = usr.id === currentUser.id;

                  // Compute accuracy for ranking display
                  const accuracy = usr.predictionsCount > 0 ? Math.round((usr.hitsCount / usr.predictionsCount) * 100) : 0;

                  return (
                    <div
                      key={usr.id}
                      className={`p-3 rounded-xl flex items-center justify-between border transition-all ${
                        isCur
                          ? 'bg-immersive-green/10 border-immersive-green text-immersive-green shadow-[0_0_15px_rgba(0,255,65,0.05)]'
                          : 'bg-immersive-slate border-white/5 text-white/80'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {/* Position circle */}
                        <div className={`w-6 h-6 rounded text-xs font-black flex items-center justify-center font-display ${
                          position === 1 ? 'bg-amber-400 text-black shadow-glow-sm/30' :
                          position === 2 ? 'bg-zinc-200 text-black' :
                          position === 3 ? 'bg-amber-700 text-white' :
                          'bg-white/5 text-white/40 border border-white/5'
                        }`}>
                          {position}
                        </div>

                        <div>
                          <span className={`text-xs font-black leading-none block font-display uppercase tracking-tight ${isCur ? 'text-immersive-green' : 'text-white'}`}>
                            {usr.name} {isCur && ' (Tú)'}
                          </span>
                          <span className="text-[9px] text-white/40 font-mono">
                            Eficacia: {accuracy}% ({usr.hitsCount} aciertos)
                          </span>
                        </div>
                      </div>

                      <div className="text-right font-mono text-xs">
                        <strong className="block font-black text-immersive-green tracking-tight">{usr.points} pts</strong>
                        <span className="text-[9px] text-white/40">{usr.predictionsCount} pronós.</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CLAIM TICKETS PROMO CODES */}
        {activeClientTab === 'claim' && (
          <div id="tab-client-claim" className="space-y-4 animate-in fade-in">
            <div className="text-center bg-immersive-slate p-4 border border-white/5 rounded-2xl space-y-2 shadow-inner">
              <Gift size={28} className="text-immersive-green mx-auto animate-bounce" />
              <h3 className="text-xs font-black text-white font-display uppercase tracking-wider">Reclamar Puntos por Consumo</h3>
              <p className="text-[11px] text-white/50 max-w-[300px] mx-auto leading-relaxed">
                Ingresa el código proporcionado en tu factura de consumo en el restaurante deportivo para acreditar puntos adicionales a tu cuenta de fidelización.
              </p>
            </div>

            <form onSubmit={handleClaim} className="space-y-3.5">
              <div className="space-y-1">
                <input
                  type="text"
                  id="input-claim-code"
                  placeholder="Escribe el código Ej: GOL-73KXA"
                  value={claimInput}
                  onChange={e => setClaimInput(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-center text-sm font-mono tracking-widest text-[#00FF41] placeholder:text-white/20 uppercase focus:outline-none focus:border-immersive-green focus:ring-1 focus:ring-immersive-green/10"
                />
              </div>

              <button
                type="submit"
                id="btn-claim-submit"
                className="w-full bg-immersive-green hover:bg-immersive-green/90 text-black font-black uppercase tracking-widest py-3 rounded-xl text-xs font-display cursor-pointer flex items-center justify-center gap-1 shadow-glow transition-transform hover:scale-[1.01]"
              >
                Cargar Puntos de Código
              </button>

              {claimErr && <div className="p-3 bg-red-950/40 border border-red-900/30 text-red-400 rounded-xl text-xs text-center">{claimErr}</div>}
              {claimSucc && <div className="p-3 bg-immersive-green/15 border border-immersive-green/30 text-immersive-green rounded-xl text-xs text-center flex items-center justify-center gap-1.5 font-bold animate-pulse"><CheckCircle size={14} /> {claimSucc}</div>}
            </form>

            {/* Quick Helper code hint block for demonstration */}
            <div className="p-3 bg-immersive-dark border border-white/10 rounded-xl space-y-1">
              <span className="text-[9px] text-[#00FF41] font-black uppercase tracking-wider block">💡 Códigos para Probar hoy:</span>
              <p className="text-[10px] text-white/50 leading-relaxed">
                Puedes probar insertando códigos válidos en caché como: <strong className="text-immersive-green font-mono font-bold">GOL-73KXA</strong> (+50 pts) o <strong className="text-immersive-green font-mono font-bold">MUNDIAL-100K</strong> (+100 pts) o entra al rol de Administración para generar tus propios códigos con valores e importes de compra personalizados.
              </p>
            </div>
          </div>
        )}

        {/* TAB 4: MY PROGRESS & SYSTEM BADGES */}
        {activeClientTab === 'progress' && (
          <div id="tab-client-progress" className="space-y-6 animate-in fade-in">
            {/* KPI Performance grid */}
            <section className="grid grid-cols-2 gap-3">
              <div className="bg-immersive-slate p-4 rounded-xl border border-white/5 text-center shadow-inner">
                <span className="text-[9px] text-white/40 uppercase tracking-widest font-display block mb-0.5">EFECTIVIDAD</span>
                <span className="text-2xl font-black text-immersive-green font-mono">{effectiveness}%</span>
                <span className="text-[9px] text-white/40 block mt-1">{currentUser.hitsCount} aciertos / {currentUser.predictionsCount} jugadas</span>
              </div>

              <div className="bg-immersive-slate p-4 rounded-xl border border-white/5 text-center shadow-inner">
                <span className="text-[9px] text-white/40 uppercase tracking-widest font-display block mb-0.5">RACHA DE FUEGO</span>
                <span className="text-2xl font-black text-amber-500 font-mono flex items-center justify-center gap-1">
                  {currentUser.streak} <Flame size={18} className="text-amber-500 fill-amber-500 inline" />
                </span>
                <span className="text-[9px] text-white/40 block mt-1">Récord histórico: {currentUser.maxStreak}</span>
              </div>
            </section>

            {/* Unlocked badges bento row */}
            <div className="space-y-2.5">
              <h3 className="text-[10px] font-black text-immersive-green uppercase tracking-widest font-display mb-1 flex items-center gap-1">
                <Sparkles size={13} className="text-[#00FF41]" /> Insignias Deportivas Desbloqueadas ({userBadges.length} de 6)
              </h3>

              <div className="grid grid-cols-2 gap-2.5">
                {userBadges.map((bdg, idx) => (
                  <div key={idx} className="bg-immersive-slate border border-white/5 p-3 rounded-xl flex gap-2 items-start relative overflow-hidden shadow-inner font-sans">
                    {/* Tiny visual badge sparkle light effect */}
                    <div className="absolute top-0 right-0 w-8 h-8 bg-immersive-green/5 rounded-full blur-sm"></div>
                    
                    <div className="w-8 h-8 rounded bg-immersive-green/10 border border-immersive-green/20 text-[#00FF41] flex items-center justify-center shrink-0 mt-0.5">
                      <Star size={14} className="fill-immersive-green/45" />
                    </div>

                    <div className="space-y-0.5">
                      <h4 className="text-[10px] font-black text-white leading-tight font-display uppercase tracking-tight">{bdg.title}</h4>
                      <p className="text-[9px] text-white/40 leading-snug">{bdg.description}</p>
                    </div>
                  </div>
                ))}

                {userBadges.length === 0 && (
                  <div className="col-span-2 text-center p-6 text-white/40 text-xs italic bg-white/5 rounded-xl border border-white/5">
                    Sigue haciendo pronósticos y canjeando códigos para ganar tus insignias del Mundial.
                  </div>
                )}
              </div>
            </div>

            {/* Loyalty points transactional historics */}
            <PointsHistory userLogs={userLogs} currentUser={currentUser} />
          </div>
        )}
      </div>

       {/* MODAL: POPUP DIALOGUE PLACING FORECASTS/PREDICTIONS */}
      {predictingMatch && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-immersive-dark border border-white/10 w-full max-w-sm rounded-[24px] p-6 space-y-4 shadow-glow animate-in zoom-in-95 duration-200 font-sans">
            <div className="text-center space-y-1">
              <span className="text-[8px] bg-white/5 px-2 py-0.5 rounded text-white/40 uppercase tracking-widest font-mono font-bold block w-fit mx-auto">{predictingMatch.stage}</span>
              <h4 className="text-sm font-black text-white font-display uppercase tracking-tight">INGRESAR PRONÓSTICO DEPORTIVO</h4>
            </div>

            <form onSubmit={handlePredictSubmit} className="space-y-4">
              {/* Outcome picker buttons */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPickWinner('LOCAL')}
                  className={`py-2 px-1 rounded-xl text-center border font-display font-black text-xs transition-colors cursor-pointer ${
                    pickWinner === 'LOCAL'
                      ? 'bg-immersive-green/10 border-immersive-green text-immersive-green shadow-glow-sm'
                      : 'bg-white/5 border-white/5 text-white/40 hover:bg-white/10'
                  }`}
                >
                  <span className="text-lg block mb-0.5">{predictingMatch.homeFlag}</span>
                  Gana Local
                </button>

                <button
                  type="button"
                  onClick={() => setPickWinner('DRAW')}
                  className={`py-2 px-1 rounded-xl text-center border font-display font-black text-xs transition-all cursor-pointer ${
                    pickWinner === 'DRAW'
                      ? 'bg-immersive-green/10 border-immersive-green text-immersive-green shadow-glow-sm'
                      : 'bg-white/5 border-white/5 text-white/40 hover:bg-white/10'
                  }`}
                >
                  <span className="text-lg block mb-0.5">🤝</span>
                  Empate
                </button>

                <button
                  type="button"
                  onClick={() => setPickWinner('AWAY')}
                  className={`py-2 px-1 rounded-xl text-center border font-display font-black text-xs transition-colors cursor-pointer ${
                    pickWinner === 'AWAY'
                      ? 'bg-immersive-green/10 border-immersive-green text-immersive-green shadow-glow-sm'
                      : 'bg-white/5 border-white/5 text-white/40 hover:bg-white/10'
                  }`}
                >
                  <span className="text-lg block mb-0.5">{predictingMatch.awayFlag}</span>
                  Gana Visita
                </button>
              </div>

              {/* Exact Score inputs */}
              <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-center space-y-2.5">
                <span className="text-[9px] text-white/45 block uppercase tracking-wider font-bold font-mono">
                  Marcador Exacto Opcional (+100 pts extra!)
                </span>

                <div className="flex items-center justify-center gap-3.5">
                  <div className="flex flex-col items-center">
                    <span className="text-xs font-black text-white/80 font-display uppercase max-w-[80px] truncate mb-1">{predictingMatch.homeTeam}</span>
                    <input
                      type="number"
                      required
                      min={0}
                      value={pickHomeScore}
                      onChange={e => setPickHomeScore(parseInt(e.target.value) || 0)}
                      className="bg-immersive-slate border border-white/10 rounded-lg w-14 font-black font-mono text-center text-lg text-immersive-green py-1.5 focus:outline-none focus:border-immersive-green"
                    />
                  </div>

                  <span className="text-white/30 font-bold block pt-5">-</span>

                  <div className="flex flex-col items-center">
                    <span className="text-xs font-black text-white/80 font-display uppercase max-w-[80px] truncate mb-1">{predictingMatch.awayTeam}</span>
                    <input
                      type="number"
                      required
                      min={0}
                      value={pickAwayScore}
                      onChange={e => setPickAwayScore(parseInt(e.target.value) || 0)}
                      className="bg-immersive-slate border border-white/10 rounded-lg w-14 font-black font-mono text-center text-lg text-immersive-green py-1.5 focus:outline-none focus:border-immersive-green"
                    />
                  </div>
                </div>
              </div>

              {/* Rule reminder */}
              <div className="text-[10px] text-white/40 leading-normal flex items-start gap-1.5">
                <Info size={12} className="text-immersive-green shrink-0 mt-0.5" />
                <span>
                 Ingresar este pronóstico te otorgará automáticamente <b>+10 puntos de participación</b> en el acto. Si aciertas el ganador o empate ganas <b>+50 puntos</b>, y si logras atinar el marcador exacto sumas <b>+100 puntos</b> adicionales.
                </span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPredictingMatch(null)}
                  className="w-1/3 bg-white/5 hover:bg-white/10 border border-white/5 text-white/60 font-black py-2.5 rounded-xl text-xs font-display cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  id="btn-confirm-prediction-submit"
                  className="w-2/3 bg-immersive-green hover:bg-immersive-green/90 text-black font-black py-2.5 rounded-xl text-xs font-display transition-transform shadow-glow cursor-pointer"
                >
                  Registrar Pronóstico
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
