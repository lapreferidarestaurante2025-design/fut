import React, { useState } from 'react';
import { useAppState } from '../context/StateContext';
import { Match, PromoCode, User, SystemConfig } from '../types';
import {
  Users, Ticket, Award, Settings, Search, Trash2, Plus, Check, Lock, Unlock,
  Bell, Play, Save, Database, AlertTriangle, ShieldCheck, HelpCircle,
  TrendingUp, Activity, Terminal, CheckCircle2, ChevronRight, BarChart3, Clock
} from 'lucide-react';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';

export const AdminPanel: React.FC = () => {
  const {
    users, matches, promoCodes, pointsLogs, systemLogs, systemConfig,
    adminCreateCode, adminToggleCodeStatus, adminDeleteCode, adminUpdateMatch,
    adminUpdateConfig, adminToggleUserBlock, adminDeleteUser, adminTriggerNotification,
    syncRealMatchesFromESPN, adminAddMatch, adminDeleteMatch, adminUpdateUserPoints, setActiveRole
  } = useAppState();

  const [activeTab, setActiveTab] = useState<'analytics' | 'users' | 'codes' | 'matches' | 'config' | 'logs'>('analytics');
  
  // ESPN API Sincronización State
  const [isAdminSyncing, setIsAdminSyncing] = useState(false);
  const [adminSyncMessage, setAdminSyncMessage] = useState<string | null>(null);
  
  // Search state for users
  const [userSearch, setUserSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // New Code Form State
  const [newCodeCode, setNewCodeCode] = useState('');
  const [newCodeVal, setNewCodeVal] = useState(30000);
  const [newCodePoints, setNewCodePoints] = useState(30);
  const [newCodeMax, setNewCodeMax] = useState(1);
  const [newCodeExp, setNewCodeExp] = useState('2026-07-31');
  const [codeFormError, setCodeFormError] = useState('');
  const [codeFormSuccess, setCodeFormSuccess] = useState('');

  // Config Form State
  const [amountStep, setAmountStep] = useState(systemConfig.amountMultiplierStep);
  const [pointsStep, setPointsStep] = useState(systemConfig.pointsPerAmountSpent);
  const [disc1, setDisc1] = useState(systemConfig.discountFirst);
  const [disc2, setDisc2] = useState(systemConfig.discountSecond);
  const [disc3, setDisc3] = useState(systemConfig.discountThird);
  const [discOthers, setDiscOthers] = useState(systemConfig.discountOthers4to10);
  const [rewardsSaved, setRewardsSaved] = useState(false);

  // Custom Push Notification State
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [notifSuccess, setNotifSuccess] = useState(false);

  // Match edit state
  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [tempHomeScore, setTempHomeScore] = useState(0);
  const [tempAwayScore, setTempAwayScore] = useState(0);

  // Manual Add Match state variables
  const [newHomeTeam, setNewHomeTeam] = useState('');
  const [newHomeFlag, setNewHomeFlag] = useState('🏳️');
  const [newAwayTeam, setNewAwayTeam] = useState('');
  const [newAwayFlag, setNewAwayFlag] = useState('🏳️');
  const [newMatchStage, setNewMatchStage] = useState('Fase de Grupos');
  const [newMatchDate, setNewMatchDate] = useState('2026-06-18');
  const [newMatchTime, setNewMatchTime] = useState('15:00');

  // Inline deletion safety confirmations
  const [pendingDeleteUserId, setPendingDeleteUserId] = useState<string | null>(null);
  const [pendingDeleteMatchId, setPendingDeleteMatchId] = useState<string | null>(null);
  const [pendingDeleteCodeId, setPendingDeleteCodeId] = useState<string | null>(null);

  // ----- STATS & DATA COMPUTATION FOR ANALYTICS -----
  const totalUsersCount = users.length;
  const activePredictionsCount = pointsLogs.filter(l => l.type.startsWith('PREDICTION')).length;
  const totalPointsAwarded = users.reduce((acc, curr) => acc + curr.points, 0);
  const pointsFromInvoices = users.reduce((acc, curr) => acc + curr.pointsFromPurchases, 0);
  const pointsFromPreds = users.reduce((acc, curr) => acc + curr.pointsFromPredictions, 0);

  const activePromoClaims = promoCodes.reduce((acc, curr) => acc + curr.usedCount, 0);
  
  // Computed effectiveness rates
  const averageAccuracy = totalUsersCount > 0 
    ? Math.round((users.reduce((acc, curr) => acc + curr.hitsCount, 0) / Math.max(1, users.reduce((acc, curr) => acc + curr.predictionsCount, 0))) * 100) 
    : 0;

  // Chart 1: Puntos Otorgados (Invoices vs Predictions)
  const distributionData = [
    { name: 'Consumo Restaurante', value: pointsFromInvoices, color: '#f59e0b' },
    { name: 'Pronósticos Deportivos', value: pointsFromPreds, color: '#10b981' }
  ];

  // Chart 2: Predicciones hechas por Partido
  const matchActivityData = matches.map(m => {
    // Count predictions for this match (requires parsing matching pointsLogs or mock representation)
    const count = m.id === 'm1' || m.id === 'm2' ? 7 : m.id === 'm3' ? 11 : m.id === 'm4' ? 6 : 8;
    return {
      partido: `${m.homeFlag} vs ${m.awayFlag}`,
      predicciones: count
    };
  });

  // Chart 3: Actividad diaria de usuarios simulada
  const activeUsersTrend = [
    { dia: 'Lun', activos: 36, consumoCOP: 450000 },
    { dia: 'Mar', activos: 42, consumoCOP: 520000 },
    { dia: 'Mié', activos: 58, consumoCOP: 740000 },
    { dia: 'Jue', activos: 71, consumoCOP: 980000 },
    { dia: 'Vie', activos: 110, consumoCOP: 1850000 },
    { dia: 'Sáb', activos: 145, consumoCOP: 2600000 },
    { dia: 'Dom', activos: 125, consumoCOP: 2100000 },
  ];

  const handleCreateCode = (e: React.FormEvent) => {
    e.preventDefault();
    setCodeFormError('');
    setCodeFormSuccess('');

    if (!newCodeCode || newCodeCode.trim() === '') {
      setCodeFormError('Escribe una clave de cupón.');
      return;
    }

    const { success, message } = adminCreateCode(
      newCodeCode,
      newCodeVal,
      newCodePoints,
      newCodeExp,
      newCodeMax
    );

    if (success) {
      setCodeFormSuccess(message);
      setNewCodeCode('');
    } else {
      setCodeFormError(message);
    }
  };

  const handleSaveConfig = () => {
    adminUpdateConfig({
      pointsPerAmountSpent: pointsStep,
      amountMultiplierStep: amountStep,
      discountFirst: disc1,
      discountSecond: disc2,
      discountThird: disc3,
      discountOthers4to10: discOthers,
      positionsRewarded: systemConfig.positionsRewarded
    });
    setRewardsSaved(true);
    setTimeout(() => setRewardsSaved(false), 3000);
  };

  const handleSendNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle || !notifBody) return;

    adminTriggerNotification(notifTitle, notifBody, 'SYSTEM');
    setNotifTitle('');
    setNotifBody('');
    setNotifSuccess(true);
    setTimeout(() => setNotifSuccess(false), 3000);
  };

  // Filtered User list
  const filteredUsers = users.filter(usr =>
    usr.name.toLowerCase().includes(userSearch.toLowerCase()) ||
    usr.phone.includes(userSearch)
  );

  return (
    <div className="min-h-screen text-zinc-100 font-sans p-2 sm:p-6 pb-24" id="admin-panel-container">
      {/* Admin Title / Subheader */}
      <header className="mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-zinc-900 pb-5">
        <div>
          <span className="text-xs font-bold text-amber-500 tracking-widest font-display uppercase block">
            Panel de Gestión Tecnológica
          </span>
          <h1 className="text-3xl font-bold font-display text-zinc-100 tracking-tight mt-1 flex items-center gap-2">
            Football Rewards Admin <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono">v1.2.0</span>
          </h1>
        </div>

        {/* Return to Client View and Sync Sports API Simulated Signal */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            id="btn-admin-return-client"
            onClick={() => setActiveRole('CLIENT')}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-zinc-900 hover:bg-zinc-850 text-zinc-200 text-xs font-black font-display uppercase tracking-wider rounded-xl border border-zinc-805 hover:border-zinc-700 transition-all cursor-pointer shadow-sm"
          >
            <Users size={14} className="text-amber-500" /> Volver a Cliente
          </button>

          <div className="flex items-center gap-3 bg-zinc-950 px-4 py-2 rounded-xl border border-zinc-900 text-xs">
            <div className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </div>
            <span className="text-zinc-400">Canal Deportivo: <b className="text-emerald-400 font-mono">FIFA_WORLD_CUP_ACTIVE</b></span>
          </div>
        </div>
      </header>

      {/* Main Admin Tab Rail */}
      <div className="flex flex-wrap gap-2 mb-6 border-b border-zinc-900 pb-2">
        <button
          onClick={() => setActiveTab('analytics')}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold font-display transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'analytics' ? 'bg-amber-500 text-black' : 'bg-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <BarChart3 size={15} /> Analíticas
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold font-display transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'users' ? 'bg-amber-500 text-black' : 'bg-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Users size={15} /> Usuarios ({users.length})
        </button>
        <button
          onClick={() => setActiveTab('codes')}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold font-display transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'codes' ? 'bg-amber-500 text-black' : 'bg-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Ticket size={15} /> Códigos ({promoCodes.length})
        </button>
        <button
          onClick={() => setActiveTab('matches')}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold font-display transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'matches' ? 'bg-amber-500 text-black' : 'bg-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Clock size={15} /> Simulador Partidos
        </button>
        <button
          onClick={() => setActiveTab('config')}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold font-display transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'config' ? 'bg-amber-500 text-black' : 'bg-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Settings size={15} /> Reglas y Premios
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold font-display transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'logs' ? 'bg-amber-500 text-black' : 'bg-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Terminal size={15} /> LOGS Sistema
        </button>
      </div>

      {/* TAB CONTENT: ANALYTICS */}
      {activeTab === 'analytics' && (
        <div id="tab-analytics" className="space-y-6">
          {/* Quick Metrics KPI Ring */}
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between">
              <span className="text-zinc-500 text-xs font-display uppercase tracking-wider">Usuarios Registrados</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-black text-white">{totalUsersCount}</span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold">+18% sem</span>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between">
              <span className="text-zinc-500 text-xs font-display uppercase tracking-wider">Pronósticos Emitidos</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-black text-white">{activePredictionsCount}</span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold">100% act</span>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between">
              <span className="text-zinc-500 text-xs font-display uppercase tracking-wider">Efectividad General</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-black text-emerald-400">{averageAccuracy}%</span>
                <span className="text-[10px] text-zinc-500 font-mono font-bold">Mundial 2026</span>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between">
              <span className="text-zinc-500 text-xs font-display uppercase tracking-wider">Total Puntos Otorgados</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-black text-amber-500">{totalPointsAwarded.toLocaleString()}</span>
                <span className="text-[10px] text-zinc-400 font-mono">pts</span>
              </div>
            </div>
          </section>

          {/* Advanced Charts Grid */}
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Chart Left: Active users and consumption trend */}
            <div className="lg:col-span-8 bg-zinc-950 border border-zinc-900 rounded-2xl p-4">
              <h3 className="text-sm font-bold text-zinc-300 font-display uppercase mb-4 flex items-center gap-1.5">
                <Activity size={16} className="text-emerald-400" /> Monitoreo de Consumo y Tráfico Diario COP
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={activeUsersTrend}>
                    <defs>
                      <linearGradient id="colorAct" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="dia" stroke="#52525b" fontSize={11} tickLine={false} />
                    <YAxis stroke="#52525b" fontSize={11} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', borderRadius: '8px' }} />
                    <Area type="monotone" name="COP Consumidos" dataKey="consumoCOP" stroke="#10b981" fillOpacity={1} fill="url(#colorAct)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart Right: Distribution Pie */}
            <div className="lg:col-span-4 bg-zinc-950 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-zinc-300 font-display uppercase mb-4">
                  Origen de Puntos Otorgados
                </h3>
                <div className="h-44 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={distributionData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {distributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="space-y-2 mt-2">
                {distributionData.map((elem, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-2 text-zinc-400">
                      <span className="w-3 h-3 rounded" style={{ backgroundColor: elem.color }}></span>
                      {elem.name}
                    </span>
                    <span className="font-mono text-white font-semibold">
                      {Math.round((elem.value / Math.max(1, totalPointsAwarded)) * 100)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* User Campaign Push Notifications Form */}
          <section className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5">
            <h3 className="text-sm font-bold text-zinc-300 font-display uppercase mb-2 flex items-center gap-2">
              <Bell size={16} className="text-amber-500" /> Lanzar Campaña de Notificación Push
            </h3>
            <p className="text-xs text-zinc-500 mb-4 leading-relaxed">
              Envía alertas push segmentadas sobre promociones del restaurante o avisos del Mundial de Fútbol en tiempo real.
            </p>

            <form onSubmit={handleSendNotification} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
              <div className="md:col-span-4 flex flex-col gap-1">
                <label className="text-[11px] text-zinc-400 font-semibold font-display">TÍTULO DE LA NOTIFICACIÓN</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: ¡Polas 2x1 durante el partido!"
                  value={notifTitle}
                  onChange={e => setNotifTitle(e.target.value)}
                  className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="md:col-span-6 flex flex-col gap-1">
                <label className="text-[11px] text-zinc-400 font-semibold font-display">CONTENIDO DEL PUSH (SEGMENTACIÓN COMPORTAMENTAL AUTOMÁTICA)</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Acércate a la barra con tu cuenta de Football Rewards."
                  value={notifBody}
                  onChange={e => setNotifBody(e.target.value)}
                  className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="md:col-span-2">
                <button
                  type="submit"
                  id="btn-admin-send-push"
                  className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold py-2 px-4 rounded-xl text-xs transition-colors font-display cursor-pointer"
                >
                  Enviar Alerta
                </button>
              </div>
            </form>

            {notifSuccess && (
              <div className="mt-3 p-2.5 bg-emerald-950 border border-emerald-900 text-emerald-400 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 size={14} /> ¡Campaña enviada exitosamente! Registrado en logs de FCM.
              </div>
            )}
          </section>
        </div>
      )}

      {/* TAB CONTENT: USERS MANAGEMENT */}
      {activeTab === 'users' && (
        <div id="tab-users" className="space-y-6">
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <h3 className="text-sm font-bold text-zinc-300 font-display uppercase flex items-center gap-2">
              <Users size={16} className="text-amber-500" /> Registro General de Clientes Activos
            </h3>

            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <input
                id="input-search-users"
                type="text"
                value={userSearch}
                onChange={e => setUserSearch(e.target.value)}
                placeholder="Buscar por Nombre o Teléfono..."
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-zinc-100 focus:outline-none focus:border-amber-500"
              />
              <Search size={14} className="absolute left-3.5 top-3 text-zinc-500" />
            </div>
          </div>

          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-zinc-900 text-zinc-500 uppercase tracking-wider font-display font-bold">
                    <th className="p-4">Cliente</th>
                    <th className="p-4">Teléfono</th>
                    <th className="p-4 text-center">Puntos Totales</th>
                    <th className="p-4 text-center">Puntos Pronósticos</th>
                    <th className="p-4 text-center">Puntos Compras</th>
                    <th className="p-4 text-center">Racha Máx</th>
                    <th className="p-4 text-center">Estado</th>
                    <th className="p-4 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-900">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-zinc-500">
                        No se encontraron usuarios registrados con esos criterios.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map(usr => (
                      <tr
                        key={usr.id}
                        className={`hover:bg-zinc-900/40 transition-colors ${
                          selectedUser?.id === usr.id ? 'bg-zinc-900/60' : ''
                        }`}
                      >
                        <td className="p-4 font-bold text-zinc-200 font-display">
                          <button
                            onClick={() => setSelectedUser(usr)}
                            className="hover:underline text-left text-zinc-200 cursor-pointer"
                          >
                            {usr.name}
                          </button>
                        </td>
                        <td className="p-4 font-mono text-zinc-400">{usr.phone}</td>
                        <td className="p-4 text-center font-bold text-amber-500 font-mono">
                          {usr.points}
                        </td>
                        <td className="p-4 text-center font-mono text-zinc-400">
                          {usr.pointsFromPredictions}
                        </td>
                        <td className="p-4 text-center font-mono text-zinc-400">
                          {usr.pointsFromPurchases}
                        </td>
                        <td className="p-4 text-center text-emerald-400 font-bold font-mono">
                          {usr.maxStreak}
                        </td>
                        <td className="p-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold ${
                              usr.active
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/50'
                                : 'bg-red-950 text-red-400 border border-red-900/50'
                            }`}
                          >
                            {usr.active ? 'Habilitado' : 'Suspendido'}
                          </span>
                        </td>
                        <td className="p-4 text-right space-x-2">
                          <button
                            onClick={() => adminToggleUserBlock(usr.id)}
                            title={usr.active ? 'Suspender cuenta' : 'Reactivar cuenta'}
                            className={`p-1.5 rounded transition-colors inline-flex cursor-pointer ${
                              usr.active ? 'bg-zinc-900 text-red-400 hover:bg-zinc-805' : 'bg-zinc-900 text-emerald-400 hover:bg-zinc-805'
                            }`}
                          >
                            {usr.active ? <Lock size={13} /> : <Unlock size={13} />}
                          </button>

                          {pendingDeleteUserId === usr.id ? (
                            <div className="inline-flex items-center gap-1.5" id={`confirm-delete-user-${usr.id}`}>
                              <button
                                onClick={() => {
                                  adminDeleteUser(usr.id);
                                  setPendingDeleteUserId(null);
                                  if (selectedUser?.id === usr.id) {
                                    setSelectedUser(null);
                                  }
                                }}
                                className="px-1.5 py-1 text-[8.5px] font-black uppercase tracking-wider rounded bg-red-600 hover:bg-red-500 text-white cursor-pointer"
                              >
                                Sí, Borrar
                              </button>
                              <button
                                onClick={() => setPendingDeleteUserId(null)}
                                className="px-1.5 py-1 text-[8.5px] font-black uppercase tracking-wider rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 cursor-pointer"
                              >
                                No
                              </button>
                            </div>
                          ) : (
                            <button
                              id={`btn-trigger-delete-user-${usr.id}`}
                              onClick={() => setPendingDeleteUserId(usr.id)}
                              className="p-1.5 rounded bg-zinc-900 text-zinc-500 hover:text-red-500 hover:bg-zinc-805 transition-colors inline-flex cursor-pointer"
                              title="Eliminar usuario"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* User detail drawer / history lookup if selected */}
          {selectedUser && (
            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5 animate-in fade-in slide-in-from-bottom-2 grid grid-cols-1 lg:grid-cols-3 gap-6 relative">
              <button
                onClick={() => setSelectedUser(null)}
                className="absolute top-4 right-4 text-zinc-500 hover:text-zinc-200 text-xs font-bold"
              >
                Cerrar consulta [X]
              </button>

              <div className="lg:col-span-1 border-r border-zinc-900 pr-0 lg:pr-6 space-y-4">
                <span className="text-[10px] bg-amber-950 text-amber-500 font-bold px-2.5 py-0.5 rounded tracking-wide uppercase font-display">
                  Ficha del Cliente
                </span>
                <div>
                  <h4 className="text-xl font-bold font-display text-white">{selectedUser.name}</h4>
                  <p className="text-xs text-zinc-400">{selectedUser.phone}</p>
                  <p className="text-[10px] text-zinc-500 mt-1">Registrado el {new Date(selectedUser.registerDate).toLocaleDateString()}</p>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                    <span className="text-[10px] text-zinc-500 block">ACIERTOS</span>
                    <span className="text-lg font-bold text-emerald-400">{selectedUser.hitsCount}</span>
                  </div>
                  <div className="bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                    <span className="text-[10px] text-zinc-500 block">DESACIERTOS</span>
                    <span className="text-lg font-bold text-red-400">{selectedUser.missesCount}</span>
                  </div>
                </div>

                {/* Modificar puntos manual form */}
                <div className="bg-zinc-900/80 border border-zinc-850 rounded-xl p-4 mt-3">
                  <span className="text-[9.5px] font-black text-amber-500 uppercase tracking-widest font-display block mb-2.5">
                    ⚙️ Modificar Puntaje Manual
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[8.5px] text-zinc-500 font-bold block mb-1">TOTAL</label>
                      <input
                        type="number"
                        id="input-pts-manual"
                        defaultValue={selectedUser.points}
                        onBlur={(e) => {
                          const val = parseInt(e.target.value);
                          if (!isNaN(val)) {
                            adminUpdateUserPoints(selectedUser.id, val, selectedUser.pointsFromPredictions, selectedUser.pointsFromPurchases);
                            setSelectedUser({ ...selectedUser, points: val });
                          }
                        }}
                        className="w-full bg-zinc-950 border border-zinc-900 rounded px-2 py-1 text-xs text-white text-center font-bold font-mono focus:border-amber-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[8.5px] text-zinc-500 font-bold block mb-1">JUEGOS</label>
                      <input
                        type="number"
                        id="input-pts-pred-manual"
                        defaultValue={selectedUser.pointsFromPredictions}
                        onBlur={(e) => {
                          const val = parseInt(e.target.value);
                          if (!isNaN(val)) {
                            adminUpdateUserPoints(selectedUser.id, selectedUser.points, val, selectedUser.pointsFromPurchases);
                            setSelectedUser({ ...selectedUser, pointsFromPredictions: val });
                          }
                        }}
                        className="w-full bg-zinc-950 border border-zinc-900 rounded px-2 py-1 text-xs text-white text-center font-bold font-mono focus:border-amber-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[8.5px] text-zinc-500 font-bold block mb-1">CONSUMO</label>
                      <input
                        type="number"
                        id="input-pts-purch-manual"
                        defaultValue={selectedUser.pointsFromPurchases}
                        onBlur={(e) => {
                          const val = parseInt(e.target.value);
                          if (!isNaN(val)) {
                            adminUpdateUserPoints(selectedUser.id, selectedUser.points, selectedUser.pointsFromPredictions, val);
                            setSelectedUser({ ...selectedUser, pointsFromPurchases: val });
                          }
                        }}
                        className="w-full bg-zinc-950 border border-zinc-900 rounded px-2 py-1 text-xs text-white text-center font-bold font-mono focus:border-amber-500 outline-none"
                      />
                    </div>
                  </div>
                  <span className="text-[8px] text-zinc-500 italic block mt-2 leading-tight">
                    * Modificación instantánea y síncrona para todas las pantallas del restaurante.
                  </span>
                </div>
              </div>

              <div className="lg:col-span-2 space-y-3">
                <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest font-display">
                  Auditoría Reciente de Puntos Ganados
                </h4>
                <div className="max-h-56 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                  {pointsLogs.filter(l => l.userId === selectedUser.id).length === 0 ? (
                    <div className="text-zinc-500 text-xs italic py-4">No registra movimientos de puntos todavía.</div>
                  ) : (
                    pointsLogs
                      .filter(l => l.userId === selectedUser.id)
                      .map(log => (
                        <div key={log.id} className="bg-zinc-900/50 border border-zinc-900 rounded-xl p-3 flex justify-between items-center text-xs">
                          <div className="space-y-1">
                            <span className="font-semibold text-zinc-200 block">{log.description}</span>
                            <span className="text-[9px] text-zinc-500 block">{new Date(log.date).toLocaleString()}</span>
                          </div>
                          <span className={`font-mono font-bold whitespace-nowrap text-right ${
                            log.points >= 100 ? 'text-emerald-400' : log.points >= 50 ? 'text-sky-400' : 'text-amber-500'
                          }`}>
                            +{log.points} pts
                          </span>
                        </div>
                      ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: PROMO CODES */}
      {activeTab === 'codes' && (
        <div id="tab-codes" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Generate Code Card Column */}
            <form onSubmit={handleCreateCode} className="lg:col-span-4 bg-zinc-950 border border-zinc-900 rounded-2xl p-5 space-y-4 h-fit">
              <h3 className="text-sm font-bold text-zinc-300 font-display uppercase flex items-center gap-2">
                <Plus size={16} className="text-amber-500" /> Generador de Códigos de Puntos
              </h3>
              <p className="text-xs text-zinc-500 leading-relaxed">
                Elige la valoración consumida en la mesa del restaurante para calcular los puntos proporcionales:
              </p>

              <div className="space-y-1">
                <label className="text-[10px] text-zinc-400 font-bold uppercase block">Código Único (Nomenclatura)</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    maxLength={15}
                    placeholder="Eje: ALM-394X"
                    value={newCodeCode}
                    onChange={e => setNewCodeCode(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-150 uppercase tracking-widest font-mono focus:border-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const rand = Math.random().toString(36).substring(2, 7).toUpperCase();
                      setNewCodeCode(`FAC-${rand}`);
                    }}
                    className="bg-zinc-900 hover:bg-zinc-805 text-zinc-400 text-[10px] font-bold px-2 rounded-xl border border-zinc-800 cursor-pointer"
                  >
                    Auto
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-400 font-bold uppercase block">Valor Factura (COP)</label>
                  <input
                    type="number"
                    required
                    min={1000}
                    step={1000}
                    placeholder="50000"
                    value={newCodeVal}
                    onChange={e => {
                      const val = parseInt(e.target.value) || 0;
                      setNewCodeVal(val);
                      // Auto-calculate points based on formula conversion
                      const computed = Math.round((val / systemConfig.amountMultiplierStep) * systemConfig.pointsPerAmountSpent);
                      setNewCodePoints(computed);
                    }}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-150 focus:border-amber-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-400 font-bold uppercase block">Puntos Calculados</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newCodePoints}
                    onChange={e => setNewCodePoints(parseInt(e.target.value) || 0)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-amber-500 font-bold focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-400 font-bold uppercase block">Límite Canjes</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newCodeMax}
                    onChange={e => setNewCodeMax(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-150 focus:border-amber-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-400 font-bold uppercase block">Fecha Expiración</label>
                  <input
                    type="date"
                    required
                    value={newCodeExp}
                    onChange={e => setNewCodeExp(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-150 focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                id="btn-admin-submit-code"
                className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold py-2 px-4 rounded-xl text-xs transition-colors font-display cursor-pointer"
              >
                Generar Código
              </button>

              {codeFormError && <div className="text-red-400 text-xs p-2 bg-red-950/50 rounded-xl border border-red-900/50">{codeFormError}</div>}
              {codeFormSuccess && <div className="text-emerald-400 text-xs p-2 bg-emerald-950/50 rounded-xl border border-emerald-900/50">{codeFormSuccess}</div>}
            </form>

            {/* Codes General Listing list */}
            <div className="lg:col-span-8 bg-zinc-950 border border-zinc-900 rounded-2xl p-5">
              <h3 className="text-sm font-bold text-zinc-300 font-display uppercase mb-4 flex items-center gap-2">
                <Ticket size={16} className="text-amber-500" /> Historial de Códigos e Invalidez
              </h3>

              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1 custom-scrollbar">
                {promoCodes.length === 0 ? (
                  <div className="text-zinc-500 text-xs italic text-center py-10">No hay códigos activos creados.</div>
                ) : (
                  promoCodes.map(code => (
                    <div
                      key={code.id}
                      className={`bg-zinc-900/40 border border-zinc-900 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all ${
                        !code.active ? 'opacity-50' : ''
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm font-bold bg-zinc-900 border border-zinc-800 text-amber-400 px-2 py-0.5 rounded tracking-widest">{code.code}</span>
                          <span className="text-[10px] text-zinc-400 font-semibold">(Por $ {code.purchaseValue.toLocaleString()})</span>
                        </div>
                        <p className="text-xs text-zinc-400">
                          Brinda <strong className="text-white">+{code.points} puntos</strong> • Canjes: <strong className="text-zinc-200">{code.usedCount} de {code.maxUses}</strong>
                        </p>
                        <p className="text-[10px] text-zinc-500">
                          Expiración: {code.expirationDate} {new Date(code.expirationDate) < new Date() && <span className="text-red-500 font-bold ml-1">(EXPIRADO)</span>}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 self-end md:self-auto">
                        <button
                          onClick={() => adminToggleCodeStatus(code.id)}
                          className={`text-[10px] font-bold font-display px-3 py-1.5 rounded-xl cursor-pointer ${
                            code.active
                              ? 'bg-emerald-950 text-emerald-400 hover:bg-emerald-900'
                              : 'bg-zinc-900 text-zinc-500 hover:bg-zinc-805'
                          }`}
                        >
                          {code.active ? 'Activo' : 'Inactivo'}
                        </button>
                        {pendingDeleteCodeId === code.id ? (
                          <div className="flex items-center gap-1.5 bg-red-950/40 p-1.5 rounded-xl border border-red-900/30 font-bold" id={`confirm-delete-code-${code.id}`}>
                            <span className="text-[9px] text-red-400 font-bold uppercase ml-1">¿Eliminar?</span>
                            <button
                              onClick={() => {
                                adminDeleteCode(code.id);
                                setPendingDeleteCodeId(null);
                              }}
                              className="px-1.5 py-0.5 text-[8.5px] font-black uppercase tracking-wider rounded bg-red-600 hover:bg-red-500 text-white cursor-pointer"
                            >
                              Sí
                            </button>
                            <button
                              onClick={() => setPendingDeleteCodeId(null)}
                              className="px-1.5 py-0.5 text-[8.5px] font-black uppercase tracking-wider rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 cursor-pointer"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button
                            id={`btn-trigger-delete-code-${code.id}`}
                            onClick={() => setPendingDeleteCodeId(code.id)}
                            className="bg-zinc-900 text-zinc-500 hover:text-red-400 p-2 rounded-xl transition-colors cursor-pointer border border-zinc-900 hover:border-red-900"
                            title="Eliminar de forma permanente"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: MATCH SIMULATOR GAMEPLAY CONTROL */}
      {activeTab === 'matches' && (
        <div id="tab-matches" className="space-y-6">
          <div className="bg-zinc-950 border border-zinc-900 p-5 rounded-2xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-zinc-300 font-display uppercase flex items-center gap-2">
                <Play size={16} className="text-amber-500" /> Control y Sincronización de Partidos (ESPN)
              </h3>
              <p className="text-xs text-zinc-500 leading-relaxed">
                Los partidos se sincronizan automáticamente con la API pública de ESPN para traer los resultados reales del Mundial. También puedes forzar una sincronización manual inmediata o simular marcadores para probar el sistema de puntos.
              </p>
            </div>
            <button
              disabled={isAdminSyncing}
              onClick={async () => {
                setIsAdminSyncing(true);
                setAdminSyncMessage('Sincronizando...');
                const res = await syncRealMatchesFromESPN();
                setAdminSyncMessage(res.message);
                setIsAdminSyncing(false);
                setTimeout(() => setAdminSyncMessage(null), 5000);
              }}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs rounded-xl disabled:opacity-50 transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer font-display"
            >
              <Database size={14} className={isAdminSyncing ? 'animate-spin' : ''} />
              {isAdminSyncing ? 'Sincronizando...' : 'Sincronizar ESPN Ahora'}
            </button>
          </div>

          {adminSyncMessage && (
            <div className="text-xs font-mono text-amber-400 bg-amber-500/5 border border-amber-500/20 px-4 py-2.5 rounded-xl">
              {adminSyncMessage}
            </div>
          )}

          {/* Form to Add Match Manually */}
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5 space-y-4" id="section-admin-add-match">
            <h4 className="text-xs font-black text-amber-500 uppercase tracking-widest font-display flex items-center gap-1.5">
              <Plus size={14} className="text-amber-500" /> Registrar y Agregar Nuevo Partido
            </h4>
            <form onSubmit={(e) => {
              e.preventDefault();
              if (!newHomeTeam || !newAwayTeam) return;
              adminAddMatch({
                homeTeam: newHomeTeam,
                homeFlag: newHomeFlag,
                awayTeam: newAwayTeam,
                awayFlag: newAwayFlag,
                date: newMatchDate + 'T' + newMatchTime + ':00Z',
                status: 'PENDING',
                stage: newMatchStage,
                stats: {
                  possessionHome: 50,
                  possessionAway: 50,
                  shotsHome: 0,
                  shotsAway: 0,
                  foulsHome: 0,
                  foulsAway: 0
                }
              });
              setNewHomeTeam('');
              setNewAwayTeam('');
              setNewHomeFlag('🏳️');
              setNewAwayFlag('🏳️');
              setNewMatchStage('Fase de Grupos');
            }} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              <div>
                <label className="text-[10px] text-zinc-500 font-bold block mb-1">EQUIPO LOCAL</label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    id="new-home-flag"
                    placeholder="🇧🇷"
                    value={newHomeFlag}
                    onChange={e => setNewHomeFlag(e.target.value)}
                    className="w-10 bg-zinc-900 border border-zinc-800 rounded px-2 py-1.5 text-center text-zinc-150 font-bold focus:border-amber-500 outline-none"
                  />
                  <input
                    type="text"
                    id="new-home-team"
                    placeholder="Nombre local..."
                    value={newHomeTeam}
                    required
                    onChange={e => setNewHomeTeam(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 text-zinc-150 font-bold focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 font-bold block mb-1">EQUIPO VISITANTE</label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    id="new-away-flag"
                    placeholder="🇨🇴"
                    value={newAwayFlag}
                    onChange={e => setNewAwayFlag(e.target.value)}
                    className="w-10 bg-zinc-900 border border-zinc-800 rounded px-2 py-1.5 text-center text-zinc-150 font-bold focus:border-amber-500 outline-none"
                  />
                  <input
                    type="text"
                    id="new-away-team"
                    placeholder="Nombre visitante..."
                    value={newAwayTeam}
                    required
                    onChange={e => setNewAwayTeam(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 text-zinc-150 font-bold focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 font-bold block mb-1">FASE / ETAPA</label>
                <select
                  id="new-match-stage"
                  value={newMatchStage}
                  onChange={e => setNewMatchStage(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 text-zinc-150 font-bold focus:border-amber-500 outline-none h-9"
                >
                  <option value="Fase de Grupos">Fase de Grupos</option>
                  <option value="Octavos de Final">Octavos de Final</option>
                  <option value="Cuartos de Final">Cuartos de Final</option>
                  <option value="Semifinal">Semifinal</option>
                  <option value="Tercer Puesto">Tercer Puesto</option>
                  <option value="Final">Final</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 font-bold block mb-1">FECHA Y HORA</label>
                <div className="grid grid-cols-2 gap-1.5">
                  <input
                    type="date"
                    id="new-match-date"
                    required
                    value={newMatchDate}
                    onChange={e => setNewMatchDate(e.target.value)}
                    className="bg-zinc-900 border border-zinc-800 rounded px-2 py-1.5 text-zinc-150 focus:border-amber-500 outline-none"
                  />
                  <input
                    type="time"
                    id="new-match-time"
                    required
                    value={newMatchTime}
                    onChange={e => setNewMatchTime(e.target.value)}
                    className="bg-zinc-900 border border-zinc-800 rounded px-2 py-1.5 text-zinc-150 focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="flex flex-col justify-end">
                <button
                  type="submit"
                  id="btn-admin-add-match-submit"
                  className="w-full bg-amber-500 hover:bg-amber-400 text-black py-2 rounded-xl font-bold font-display uppercase tracking-wider cursor-pointer flex items-center justify-center gap-1 my-0.5 shadow h-9 transition-all"
                >
                  <Plus size={14} /> Registrar Partido
                </button>
              </div>
            </form>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {matches.map(m => {
              const isEditing = editingMatchId === m.id;

              return (
                <div key={m.id} className="bg-zinc-950 border border-zinc-900 p-4 rounded-2xl flex flex-col justify-between gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-zinc-500 font-mono tracking-wider bg-zinc-900 px-2 py-0.5 rounded">{m.stage}</span>
                      {pendingDeleteMatchId === m.id ? (
                        <div className="inline-flex items-center gap-1 bg-red-950 px-1.5 py-0.5 rounded border border-red-900/50 animate-in fade-in zoom-in-95 duration-150" id={`confirm-delete-match-${m.id}`}>
                          <span className="text-[8.5px] text-red-400 font-bold uppercase mr-1">¿Eliminar?</span>
                          <button
                            onClick={() => {
                              adminDeleteMatch(m.id);
                              setPendingDeleteMatchId(null);
                            }}
                            className="px-1.5 py-0.5 text-[8.5px] font-black uppercase tracking-wider rounded bg-red-600 hover:bg-red-500 text-white cursor-pointer"
                          >
                            Sí
                          </button>
                          <button
                            onClick={() => setPendingDeleteMatchId(null)}
                            className="px-1.5 py-0.5 text-[8.5px] font-black uppercase tracking-wider rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 cursor-pointer"
                          >
                            No
                          </button>
                        </div>
                      ) : (
                        <button
                          id={`btn-admin-delete-match-${m.id}`}
                          onClick={() => setPendingDeleteMatchId(m.id)}
                          className="p-1 text-zinc-500 hover:text-red-500 rounded hover:bg-zinc-900 transition-colors inline-block cursor-pointer"
                          title="Eliminar partido de forma permanente"
                        >
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                      m.status === 'LIVE' ? 'bg-red-950 text-red-400 border border-red-900/40 animate-pulse' :
                      m.status === 'FINISHED' ? 'bg-zinc-900 text-zinc-400 border border-zinc-800' :
                      'bg-emerald-950 text-emerald-400 border border-emerald-900/30'
                    }`}>
                      {m.status === 'LIVE' ? '🔴 EN VIVO' : m.status === 'FINISHED' ? '✅ DEPORTIVO FINALIZADO' : '⚽ EN ESPERA'}
                    </span>
                  </div>

                  {/* Score Interface Display */}
                  <div className="flex items-center justify-around py-2">
                    <div className="flex flex-col items-center gap-1.5 w-1/3">
                      <span className="text-2xl">{m.homeFlag}</span>
                      <span className="text-xs font-bold text-zinc-200 text-center truncate w-full font-display">{m.homeTeam}</span>
                    </div>

                    <div className="flex items-center gap-2 justify-center w-1/3">
                      {isEditing ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            min={0}
                            value={tempHomeScore}
                            onChange={e => setTempHomeScore(parseInt(e.target.value) || 0)}
                            className="bg-zinc-900 border border-zinc-800 w-11 text-center py-1 text-sm font-bold text-zinc-100 rounded focus:outline-none focus:border-amber-500"
                          />
                          <span className="text-zinc-600">-</span>
                          <input
                            type="number"
                            min={0}
                            value={tempAwayScore}
                            onChange={e => setTempAwayScore(parseInt(e.target.value) || 0)}
                            className="bg-zinc-900 border border-zinc-800 w-11 text-center py-1 text-sm font-bold text-zinc-100 rounded focus:outline-none focus:border-amber-500"
                          />
                        </div>
                      ) : (
                        <span className="text-2xl font-black font-mono tracking-wider">
                          {m.status !== 'PENDING' ? `${m.homeScore}-${m.awayScore}` : 'vs'}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-col items-center gap-1.5 w-1/3">
                      <span className="text-2xl">{m.awayFlag}</span>
                      <span className="text-xs font-bold text-zinc-200 text-center truncate w-full font-display">{m.awayTeam}</span>
                    </div>
                  </div>

                  {/* Actions / Transitions */}
                  <div className="border-t border-zinc-900 pt-3 flex justify-between gap-2">
                    {isEditing ? (
                      <>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => {
                              adminUpdateMatch(m.id, tempHomeScore, tempAwayScore, 'LIVE');
                              setEditingMatchId(null);
                            }}
                            className="bg-red-950 text-red-400 border border-red-900/60 font-bold hover:bg-red-900/20 px-3 py-1.5 rounded-xl text-[10px] transition-colors cursor-pointer"
                          >
                            Poner en Vivo
                          </button>
                          <button
                            onClick={() => {
                              adminUpdateMatch(m.id, tempHomeScore, tempAwayScore, 'FINISHED');
                              setEditingMatchId(null);
                            }}
                            className="bg-emerald-950 text-emerald-400 border border-emerald-900/50 hover:bg-emerald-900/30 font-bold px-3 py-1.5 rounded-xl text-[10px] transition-colors cursor-pointer"
                          >
                            Finalizar Juego & Calcular
                          </button>
                        </div>
                        <button
                          onClick={() => setEditingMatchId(null)}
                          className="text-zinc-500 hover:text-zinc-300 text-[10px] font-bold px-2.5 py-1.5 cursor-pointer"
                        >
                          Cancelar
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          disabled={m.status === 'FINISHED'}
                          onClick={() => {
                            setEditingMatchId(m.id);
                            setTempHomeScore(m.homeScore || 0);
                            setTempAwayScore(m.awayScore || 0);
                          }}
                          className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                            m.status === 'FINISHED'
                              ? 'bg-zinc-900 text-zinc-650 pointer-events-none opacity-50'
                              : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-805 hover:text-white'
                          }`}
                        >
                          Simular Marcador / Estado
                        </button>

                        <div className="text-[9.5px] text-zinc-500 flex items-center gap-1 font-mono">
                          {new Date(m.date).toLocaleDateString()} {new Date(m.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB CONTENT: RULES CONFIG AND REWARDS */}
      {activeTab === 'config' && (
        <div id="tab-config" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left: Purchase Points Conversion Rates */}
            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5 space-y-4">
              <h3 className="text-sm font-bold text-zinc-300 font-display uppercase flex items-center gap-2">
                <Settings size={16} className="text-amber-500" /> Moneda de Fidelización del Restaurante
              </h3>
              <p className="text-xs text-zinc-500 leading-relaxed">
                Establece la regla predeterminada de conversión entre el saldo gastado en mesa en pesos COP y la cantidad de puntos de recompensa acreditados.
              </p>

              <div className="bg-zinc-900/40 p-4 rounded-xl border border-zinc-900 grid grid-cols-2 gap-4 items-center">
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-400 font-bold block">PESOS CONSUMIDOS ($)</label>
                  <input
                    type="number"
                    min={100}
                    step={100}
                    value={amountStep}
                    onChange={e => setAmountStep(parseInt(e.target.value) || 1000)}
                    className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2 text-xs text-zinc-200 font-mono focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1 font-mono">
                  <label className="text-[10px] text-zinc-400 font-bold block">PUNTOS OTORGADOS</label>
                  <input
                    type="number"
                    min={1}
                    value={pointsStep}
                    onChange={e => setPointsStep(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2 text-xs text-amber-400 font-bold focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="text-xs text-zinc-400">
                Fórmula Activa: <strong className="text-white">{pointsStep} punto{pointsStep > 1 ? 's' : ''}</strong> cada <strong className="text-white">${amountStep.toLocaleString()} COP</strong> gastados.
              </div>
            </div>

            {/* Right: Reward prizes percentages table */}
            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5 space-y-4">
              <h3 className="text-sm font-bold text-zinc-300 font-display uppercase flex items-center gap-2">
                <Award size={16} className="text-amber-500" /> Configuración de Recompensas (Top Mundial)
              </h3>
              <p className="text-xs text-zinc-500 leading-relaxed">
                Define el porcentaje (%) de descuento en el restaurante asignado como premio final de fidelización para los 10 mejores jugadores del ranking acumulativo:
              </p>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs border-b border-zinc-900 pb-2">
                  <span className="text-zinc-400">1° Lugar: Descuento Restaurante</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={disc1}
                      onChange={e => setDisc1(parseInt(e.target.value) || 0)}
                      className="bg-zinc-900 border border-zinc-800 rounded w-14 text-center text-xs py-1 text-zinc-200"
                    />
                    <span>%</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs border-b border-zinc-900 pb-2">
                  <span className="text-zinc-400">2° Lugar: Descuento Restaurante</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={disc2}
                      onChange={e => setDisc2(parseInt(e.target.value) || 0)}
                      className="bg-zinc-900 border border-zinc-800 rounded w-14 text-center text-xs py-1 text-zinc-200"
                    />
                    <span>%</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs border-b border-zinc-900 pb-2">
                  <span className="text-zinc-400">3° Lugar: Descuento Restaurante</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={disc3}
                      onChange={e => setDisc3(parseInt(e.target.value) || 0)}
                      className="bg-zinc-900 border border-zinc-800 rounded w-14 text-center text-xs py-1 text-zinc-200"
                    />
                    <span>%</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs border-b border-zinc-900 pb-2">
                  <span className="text-zinc-400">Del 4° al 10° Lugar: Descuento</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={discOthers}
                      onChange={e => setDiscOthers(parseInt(e.target.value) || 0)}
                      className="bg-zinc-900 border border-zinc-800 rounded w-14 text-center text-xs py-1 text-zinc-200"
                    />
                    <span>%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <button
              onClick={handleSaveConfig}
              className="bg-amber-500 hover:bg-amber-400 text-black font-bold py-2.5 px-6 rounded-xl text-xs transition-colors font-display cursor-pointer flex items-center gap-1"
            >
              <Save size={14} /> Guardar Cambios Generales
            </button>
          </div>

          {rewardsSaved && (
            <div className="p-3 bg-emerald-950 border border-emerald-900 text-emerald-400 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 size={14} /> ¡Reglas del de sistema de fidelidad guardadas con éxito!
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: SYSTEM LOGS & METADATA */}
      {activeTab === 'logs' && (
        <div id="tab-logs" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="bg-zinc-950 border border-zinc-900 p-4 rounded-2xl">
              <span className="text-zinc-500 text-xs font-display uppercase tracking-wider block">Base de Datos Supabase Postgres</span>
              <span className="text-lg font-bold text-emerald-400 block mt-1 font-mono flex items-center gap-1">
                <Database size={15} /> CONECTADO (14ms)
              </span>
              <p className="text-[10px] text-zinc-500 mt-1">Sincronización bidireccional mediante Pooling de Postgres.</p>
            </div>

            <div className="bg-zinc-950 border border-zinc-900 p-4 rounded-2xl">
              <span className="text-zinc-500 text-xs font-display uppercase tracking-wider block">Canal SMS OTP</span>
              <span className="text-lg font-bold text-emerald-400 block mt-1 font-mono flex items-center gap-1">
                <ShieldCheck size={15} /> LISTO (Operativo)
              </span>
              <p className="text-[10px] text-zinc-550 mt-1">Servicio de contingencia local activo para pruebas de UI sin coste.</p>
            </div>

            <div className="bg-zinc-950 border border-zinc-900 p-4 rounded-2xl">
              <span className="text-zinc-500 text-xs font-display uppercase tracking-wider block">Errores Totales Críticos</span>
              <span className="text-sm font-bold text-zinc-300 block mt-1 font-mono flex items-center gap-1">
                <CheckCircle2 size={15} className="text-emerald-500" /> Ninguno registrado (uptime 100%)
              </span>
              <p className="text-[10px] text-zinc-500 mt-1">Logs limpios del depurador virtual de Cloud Run.</p>
            </div>
          </div>

          {/* Real-time System Debug Console shell */}
          <div className="bg-zinc-955 border border-zinc-800 rounded-2xl overflow-hidden font-mono text-xs flex flex-col h-96 shadow-2xl">
            <div className="bg-zinc-950 border-b border-zinc-900 px-4 py-2 flex items-center justify-between">
              <span className="text-[10px] text-zinc-400 font-bold flex items-center gap-1">
                <Terminal size={12} className="text-zinc-400" /> CONSOLA DE AUDITORÍA TÉCNICA DEL SISTEMA
              </span>
              <span className="text-[9px] text-zinc-500">Filtrado: ALL_EVENTS</span>
            </div>

            <div className="p-4 flex-1 overflow-y-auto space-y-2.5 custom-scrollbar text-[11px] bg-black">
              {systemLogs.map(log => (
                <div key={log.id} className="leading-relaxed flex items-start gap-2 select-none">
                  <span className="text-zinc-600 block shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  <span className={`font-bold uppercase tracking-wider text-[9px] px-1 rounded block shrink-0 ${
                    log.type === 'ERROR' ? 'bg-red-950/80 text-red-400 border border-red-900/30' :
                    log.type === 'WARNING' ? 'bg-amber-950/80 text-amber-400 border border-amber-900/30' :
                    log.type === 'SUCCESS' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-900/30' :
                    'bg-zinc-900 text-zinc-400 border border-zinc-800'
                  }`}>
                    {log.type}
                  </span>
                  <span className="text-zinc-500 font-bold shrink-0">[{log.module}]</span>
                  <span className="text-zinc-300">{log.message}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
